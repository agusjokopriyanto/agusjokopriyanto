<?php
require_once 'Dotenv.php';
require_once 'Loader.php';
require_once 'Validator.php';
