<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model
{
	public function get($table, $data = null, $where = null)
	{
		if ($data != null) {
			return $this->db->get_where($table, $data)->row_array();
		} else {
			return $this->db->get_where($table, $where)->result_array();
		}
	}

	public function update($table, $pk, $id, $data)
	{
		$this->db->where($pk, $id);
		return $this->db->update($table, $data);
	}
	public function update2($table, $where, $data)
	{
		$this->db->where($where);
		return $this->db->update($table, $data);
	}

	public function insert($table, $data, $batch = false)
	{
		return $batch ? $this->db->insert_batch($table, $data) : $this->db->insert($table, $data);
	}

	public function delete($table, $pk, $id)
	{
		return $this->db->delete($table, [$pk => $id]);
	}

	public function delete_d($table, $where)
	{
		return $this->db->delete($table, $where);
	}

	public function getUsers($id)
	{
		/**
		 * ID disini adalah untuk data yang tidak ingin ditampilkan.
		 * Maksud saya disini adalah
		 * tidak ingin menampilkan data user yang digunakan,
		 * pada managemen data user
		 */
		$this->db->where('id_user !=', $id);
		return $this->db->get('user')->result_array();
	}

	public function getBarang()
	{
		$this->db->join('kategori j', 'b.kategori_kd = j.kd_kategori');
		$this->db->join('satuan s', 'b.satuan_kd = s.kd_satuan');
		$this->db->order_by('id_barang');
		return $this->db->get('barang b')->result_array();
	}
	// get barang min
	public function getBarangMin()
	{
		$this->db->join('kategori j', 'b.kategori_kd = j.kd_kategori');
		$this->db->join('satuan s', 'b.satuan_kd = s.kd_satuan');
		$this->db->order_by('stok', 'ASC');
		$this->db->limit(10);
		return $this->db->get('barang b')->result_array();
	}
	// get barang max
	public function getBarangMax()
	{
		$this->db->join('kategori j', 'b.kategori_kd = j.kd_kategori');
		$this->db->join('satuan s', 'b.satuan_kd = s.kd_satuan');
		$this->db->order_by('stok', 'DESC');
		$this->db->limit(10);
		return $this->db->get('barang b')->result_array();
	}

	// invoice dan po
	public function getPoInvoice($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		// $this->db->join('barang b', 'bm.idbarang = b.id_barang');
		// $this->db->join('po_invoice p', 'bm.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('no_po_inv', $id);
		}

		$this->db->order_by('no_po_inv', 'DESC');
		return $this->db->get('po_invoice')->result_array();
	}
	// invoice dan po detail
	public function getPoInvoiceD($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('barang b', 'bm.namabarang = b.id_barang');
		// $this->db->join('po_invoice p', 'bm.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('d_po_inv', $id);
		}

		$this->db->order_by('d_po_inv', 'DESC');
		return $this->db->get('po_invoice_d bm')->result_array();
	}

	// po
	public function getPOSup($limit = null, $id = null)
	{
		$this->db->select('*');
		$this->db->join('supplier s', 'bm.supplier_id = s.id_supplier');
		if ($limit != null) {
			$this->db->limit($limit);
		}
		if ($id != null) {
			$this->db->where('no_po', $id);
		}
		$this->db->order_by('no_po', 'DESC');
		return $this->db->get('purchase_order bm')->result_array();
	}
	public function getPurchaseorder($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		// $this->db->join('barang b', 'bm.idbarang = b.id_barang');
		// $this->db->join('po_invoice p', 'bm.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('no_po', $id);
		}

		$this->db->order_by('no_po', 'DESC');
		return $this->db->get('purchase_order')->result_array();
	}
	// po detail
	public function getPurchaseorderD($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('barang b', 'bm.barang_id = b.id_barang');
		// $this->db->join('po_invoice p', 'bm.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('d_po', $id);
		}

		$this->db->order_by('d_po', 'DESC');
		return $this->db->get('purchase_order_d bm')->result_array();
	}
	// tandaterima
	public function getTandaterima($limit = null, $id = null)
	{
		$this->db->select('*');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('id_tandaterima', $id);
		}

		$this->db->order_by('id_tandaterima', 'DESC');
		return $this->db->get('tandaterima')->result_array();
	}
	// suratjalan
	public function getSuratjalan($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('barang b', 'bm.nm_barang = b.id_barang');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('no_suratjalan', $id);
		}

		$this->db->order_by('no_suratjalan', 'DESC');
		return $this->db->get('suratjalan bm')->result_array();
	}
	// surat jalan detail
	public function getSuratjalanD($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('barang b', 'bm.nm_barang = b.id_barang');
		// $this->db->join('po_invoice p', 'bm.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('no_suratjalan', $id);
		}

		$this->db->order_by('no_suratjalan', 'DESC');
		return $this->db->get('suratjalan_d bm')->result_array();
	}

	public function getBarangMasuk($limit = null, $id_barang = null, $range = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('supplier sp', 'bm.supplier_id = sp.id_supplier');
		$this->db->join('barang b', 'bm.barang_id = b.id_barang');
		$this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id_barang != null) {
			$this->db->where('id_barang', $id_barang);
		}

		if ($range != null) {
			$this->db->where('tanggal_masuk' . ' >=', $range['mulai']);
			$this->db->where('tanggal_masuk' . ' <=', $range['akhir']);
		}

		$this->db->order_by('id_barang_masuk', 'DESC');
		return $this->db->get('barang_masuk bm')->result_array();
	}

	public function getBarangKeluar($limit = null, $id_barang = null, $range = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'bk.user_id = u.id_user');
		$this->db->join('barang b', 'bk.barang_id = b.id_barang');
		$this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
		if ($limit != null) {
			$this->db->limit($limit);
		}
		if ($id_barang != null) {
			$this->db->where('id_barang', $id_barang);
		}
		if ($range != null) {
			$this->db->where('tanggal_keluar' . ' >=', $range['mulai']);
			$this->db->where('tanggal_keluar' . ' <=', $range['akhir']);
		}
		$this->db->order_by('id_barang_keluar', 'DESC');
		return $this->db->get('barang_keluar bk')->result_array();
	}

	public function getBarangWest($limit = null, $id_barang = null, $range = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'bk.user_id = u.id_user');
		$this->db->join('barang b', 'bk.barang_id = b.id_barang');
		$this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
		if ($limit != null) {
			$this->db->limit($limit);
		}
		if ($id_barang != null) {
			$this->db->where('id_barang', $id_barang);
		}
		if ($range != null) {
			$this->db->where('tanggal_west' . ' >=', $range['mulai']);
			$this->db->where('tanggal_west' . ' <=', $range['akhir']);
		}
		$this->db->order_by('id_barang_west', 'DESC');
		return $this->db->get('barang_west bk')->result_array();
	}

	public function getBarangKeluar1($limit = null, $id_barang = null, $range = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'bk.user_id = u.id_user');
		$this->db->join('barang b', 'bk.barang_id = b.id_barang');
		$this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
		$this->db->where('kategori !=', 'eceran');
		if ($limit != null) {
			$this->db->limit($limit);
		}
		if ($id_barang != null) {
			$this->db->where('id_barang', $id_barang);
		}
		if ($range != null) {
			$this->db->where('tanggal_keluar' . ' >=', $range['mulai']);
			$this->db->where('tanggal_keluar' . ' <=', $range['akhir']);
		}
		$this->db->order_by('id_barang_keluar', 'DESC');
		return $this->db->get('barang_keluar bk')->result_array();
	}

	public function getBarangEceran($limit = null, $id_barang = null, $range = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'bk.user_id = u.id_user');
		$this->db->join('barang b', 'bk.barang_id = b.id_barang');
		$this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
		$this->db->where('kategori', 'eceran');
		if ($limit != null) {
			$this->db->limit($limit);
		}
		if ($id_barang != null) {
			$this->db->where('id_barang', $id_barang);
		}
		if ($range != null) {
			$this->db->where('tanggal_keluar' . ' >=', $range['mulai']);
			$this->db->where('tanggal_keluar' . ' <=', $range['akhir']);
		}
		$this->db->order_by('id_barang_keluar', 'DESC');
		return $this->db->get('barang_keluar bk')->result_array();
	}

	// pembukuan
	public function getPembukuan($limit = null, $id_barang = null, $range = null)
	{
		$this->db->select('*');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id_barang != null) {
			$this->db->where('id_pembukuan', $id_barang);
		}

		if ($range != null) {
			$this->db->where('tanggal' . ' >=', $range['mulai']);
			$this->db->where('tanggal' . ' <=', $range['akhir']);
		}

		$this->db->order_by('id_pembukuan', 'ASC');
		return $this->db->get('pembukuan')->result_array();
	}

	public function getMax($table, $field, $kode = null)
	{
		$this->db->select_max($field);
		if ($kode != null) {
			$this->db->like($field, $kode, 'after');
		}
		return $this->db->get($table)->row_array()[$field];
	}

	public function count($table)
	{
		return $this->db->count_all($table);
	}

	public function sum($table, $field)
	{
		$this->db->select_sum($field);
		return $this->db->get($table)->row_array()[$field];
	}

	// sum kardus
	public function sum1($table, $field)
	{
		$this->db->select_sum($field);
		$this->db->where('satuan_id', 1);
		return $this->db->get($table)->row_array()[$field];
	}

	// sum kg
	public function sum2($table, $field)
	{
		$this->db->select_sum($field);
		$this->db->where('satuan_id', 2);
		return $this->db->get($table)->row_array()[$field];
	}

	public function min($table, $field, $min)
	{
		$field = $field . ' <=';
		$this->db->where($field, $min);
		return $this->db->get($table)->result_array();
	}

	public function chartBarangMasuk($bulan)
	{
		$like = 'T-BM-' . date('y') . $bulan;
		$this->db->like('id_barang_masuk', $like, 'after');
		return count($this->db->get('barang_masuk')->result_array());
	}

	public function chartBarangKeluar($bulan)
	{
		$like = 'T-BK-' . date('y') . $bulan;
		$this->db->like('id_barang_keluar', $like, 'after');
		return count($this->db->get('barang_keluar')->result_array());
	}

	public function chartBarangWest($bulan)
	{
		$like = 'T-BW-' . date('y') . $bulan;
		$this->db->like('id_barang_west', $like, 'after');
		return count($this->db->get('barang_west')->result_array());
	}

	public function laporan($table, $mulai, $akhir)
	{
		$tgl = $table == 'barang_masuk' ? 'tanggal_masuk' : 'tanggal_keluar';
		$this->db->where($tgl . ' >=', $mulai);
		$this->db->where($tgl . ' <=', $akhir);
		return $this->db->get($table)->result_array();
	}

	public function cekStok($id)
	{
		$this->db->join('satuan s', 'b.satuan_id=s.id_satuan');
		return $this->db->get_where('barang b', ['id_barang' => $id])->row_array();
	}

	// brg masuk
	public function getBMSup($limit = null, $id = null)
	{
		$this->db->select('*');
		$this->db->join('supplier s', 'bm.supplier_id = s.id_supplier');
		if ($limit != null) {
			$this->db->limit($limit);
		}
		if ($id != null) {
			$this->db->where('no_po', $id);
		}
		$this->db->order_by('no_po', 'DESC');
		return $this->db->get('brg_masuk bm')->result_array();
	}
	public function getBMD($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('barang b', 'bm.barang_id = b.id_barang');
		// $this->db->join('po_invoice p', 'bm.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('d_po', $id);
		}

		$this->db->order_by('d_po', 'DESC');
		return $this->db->get('brg_masuk_d bm')->result_array();
	}
	public function getBMDbarang($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('barang b', 'bm.barang_id = b.id_barang');
		// $this->db->join('po_invoice p', 'bm.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('barang_id', $id);
		}

		$this->db->order_by('d_po', 'DESC');
		return $this->db->get('brg_masuk_d bm')->result_array();
	}
	public function getBMDkatsat($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('barang b', 'bm.barang_id = b.id_barang');
		$this->db->join('satuan s', 's.kd_satuan = b.satuan_kd');
		$this->db->join('kategori k', 'k.kd_kategori = b.kategori_kd');
		// $this->db->join('po_invoice p', 'bm.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('d_po', $id);
		}

		$this->db->order_by('d_po', 'DESC');
		return $this->db->get('brg_masuk_d bm')->result_array();
	}

	// penjualan
	public function getPenjualanH($limit = null, $id = null, $usr = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'penjualan.user_id = u.id_user');
		$this->db->join('sales s', 'penjualan.sales_id = s.id_sales');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('ph.no_notap', $id);
		}
		$this->db->where('penjualan.selesai', '0');
		if ($usr != null) {
			$this->db->where('penjualan.user_id', $usr);
		}
		
		$this->db->order_by('penjualan.no_notap', 'DESC');
		return $this->db->get('penjualan')->result_array();
	}
	public function getPenjualanH0($limit = null, $id = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'ph.user_id = u.id_user');
		$this->db->join('sales s', 'ph.sales_id = s.id_sales');
		// $this->db->join('barang b', 'pd.barang_id = b.id_barang');
		// $this->db->join('po_invoice p', 'pd.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('ph.no_notap', $id);
		}
		$this->db->order_by('ph.no_notap', 'DESC');
		return $this->db->get('penjualan ph')->result_array();
	}
	public function getPenjualanHw($limit = null, $id = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'ph.user_id = u.id_user');
		$this->db->join('sales s', 'ph.sales_id = s.id_sales');
		// $this->db->join('barang b', 'pd.barang_id = b.id_barang');
		// $this->db->join('po_invoice p', 'pd.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('ph.no_notap', $id);
		}
		$this->db->where('ph.status !=', 'Approve');

		$this->db->order_by('ph.no_notap', 'DESC');
		return $this->db->get('penjualan ph')->result_array();
	}
	public function getPenjualanD($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('barang b', 'pd.barang_id = b.id_barang');
		// $this->db->join('sales s', 'pd.sales_id = s.id_sales');
		// $this->db->join('po_invoice p', 'pd.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('d_pj', $id);
		}

		$this->db->order_by('d_pj', 'DESC');
		return $this->db->get('penjualan_d pd')->result_array();
	}
	public function getPenjCSDp($limit = null, $id = null, $usr = null)
	{
		$this->db->select('*');
		$this->db->join('user u', 'penjualan.user_id = u.id_user');
		$this->db->join('customer c', 'penjualan.cust_id = c.id_cust');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('penjualan.no_notap', $id);
		}
		$this->db->where('penjualan.selesai', '0');
		if ($usr != null) {
			$this->db->where('penjualan.user_id', $usr);
		}
		$this->db->where('penjualan.kd_cs', '1');
		$this->db->order_by('penjualan.no_notap', 'DESC');
		return $this->db->get('penjualan')->result_array();
	}

	// barang broken
	public function getbarangbrokenD($limit = null, $id = null)
	{
		$this->db->select('*');
		// $this->db->join('user u', 'bm.user_id = u.id_user');
		$this->db->join('barang b', 'bk.barang_id = b.id_barang');
		// $this->db->join('po_invoice p', 'bk.d_po_inv = p.no_po_inv');
		if ($limit != null) {
			$this->db->limit($limit);
		}

		if ($id != null) {
			$this->db->where('d_po', $id);
		}

		$this->db->order_by('d_po', 'DESC');
		return $this->db->get('barang_broken_d bk')->result_array();
	}
}
