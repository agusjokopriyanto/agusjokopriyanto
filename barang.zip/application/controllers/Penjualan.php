<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penjualan extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		cek_login();

		$this->load->model('Admin_model', 'admin');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$data['title'] = "Riwayat Penjualan";
		if(userdata('role')==='kasir'){
		    $data['datapo'] = $this->admin->getPenjualanH(null,null,userdata('id_user'));
		}else{
		    $data['datapo'] = $this->admin->getPenjualanH(null,null,null);
		}
		$data['pnotap'] = $this->admin->get('penjualan', null, ['selesai' => '1']);
		$this->template->load('templates/dashboard', 'penjualan/data_penjualan', $data);
	}

	public function add()
	{
		$data['title'] = "Transaksi Penjualan";
		$data['barang'] = $this->admin->get('barang', null, ['stok >' => '0']);
		$data['voucher'] = $this->admin->get('voucher', null, ['status' => '0', 'tgl_expired >=' => date('Y-m-d')]);
		$data['sales'] = $this->admin->get('sales', null);

		$kode = 'P'. userdata('id_user').'-';
		$kode_terakhir = $this->admin->getMax('penjualan', 'no_notap', $kode);
		$kode_tambah = substr($kode_terakhir, -4, 4);
		$kode_tambah++;
		$number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
		$data['no_notap'] = $kode . $number;

		$data['data_detail'] = $this->admin->getPenjualanD(null, $kode . $number);
		$this->template->load('templates/dashboard', 'penjualan/add_penjualan', $data);
	}
	
	public function validate_nego($nego)
    {
        $subtotal = $this->input->post('subtotal');
    
        if ($nego < $subtotal && $nego > -1) {
            return true; // Validation passed
        } else {
            $this->form_validation->set_message('validate_nego', 'The Harga Nego field must be greater than -1 and less than Subtotal.');
            return false; // Validation failed
        }
    }


	// validasi top invoice
	private function _validasi_t()
	{
		$this->form_validation->set_rules('tanggal_', 'Tanggal', 'required|trim');
		$this->form_validation->set_rules('user_id', 'Kasir', 'required|trim');
		$this->form_validation->set_rules('subtotal', 'Subtotal', 'required|trim');
// 		$this->form_validation->set_rules('nego', 'Harga Nego', 'required|trim|numeric|greater_than[-1]');
        // $this->form_validation->set_rules('nego', 'Harga Nego', 'required|trim|numeric|callback_validate_nego');
		$this->form_validation->set_rules('voucher', 'Voucher', 'required|trim');
		$this->form_validation->set_rules('grandtotal', 'Grandtotal', 'required|trim');
		$this->form_validation->set_rules('payment', 'Payment', 'required|trim');
		$this->form_validation->set_rules('sales_id', 'Sales', 'required|trim');
	}

	public function proses_t()
	{
	    $this->form_validation->set_rules('subtotal', 'Subtotal', 'required|trim');
        $this->form_validation->set_rules('nego', 'Harga Nego', 'required|trim|numeric|greater_than[-1]|callback_validate_nego');
		$this->_validasi_t();
		if ($this->form_validation->run() == false) {
			$this->add();
		} else {
			$input = $this->input->post(null, true);
			$insert = $this->admin->insert('penjualan', $input);

			if ($insert) {
				set_pesan('data berhasil disimpan.');
				redirect('penjualan/add');
			} else {
				set_pesan('Opps ada kesalahan!');
				redirect('penjualan/add');
			}
		}
	}
	
	public function proses_t2()
	{
	    $input = $this->input->post(null, true);
	    $this->form_validation->set_rules('subtotal', 'Subtotal', 'required|trim');
        $this->form_validation->set_rules('nego', 'Harga Nego', 'required|trim|numeric|greater_than[-1]|callback_validate_nego');
		$this->_validasi_t();
		if ($this->form_validation->run() == false) {
			$this->retur($input['no_notap']);
		} else {
			$update = $this->admin->update('penjualan', 'no_notap', $input['no_notap'], $input);

			if (update) {
				set_pesan('data berhasil disimpan.');
				redirect('penjualan');
			} else {
				set_pesan('Opps ada kesalahan!');
				redirect('penjualan/retur/' . $input['no_notap']);
			}
		}
	}

	// validasi detail invoice
	private function _validasi_d()
	{
		$this->form_validation->set_rules('barang_id', 'Produk', 'required|trim');
		$this->form_validation->set_rules('qty', 'Quantity', 'required|trim|numeric|greater_than[0]');
		$this->form_validation->set_rules('harga', 'Harga', 'required|trim|numeric|greater_than[0]');
	}
	// proses detail invoice
	public function proses_d()
	{
		$this->_validasi_d();
		if ($this->form_validation->run() == false) {
			$this->add();
		} else {
			$input = $this->input->post(null, true);
			$insert = $this->admin->insert('penjualan_d', $input);

			if ($insert) {
				// set_pesan('data berhasil disimpan.');
				redirect('penjualan/add');
			} else {
				// set_pesan('Opps ada kesalahan!');
				redirect('penjualan/add');
			}
		}
	}
	
	public function proses_d2()
	{
	    $input = $this->input->post(null, true);
		$this->_validasi_d();
		if ($this->form_validation->run() == false) {
			$this->retur($input['d_pj']);
		} else {
			
// 			echo json_encode($input);
			$insert = $this->admin->insert('penjualan_d', $input);

			if ($insert) {
				// set_pesan('data berhasil disimpan.');
				redirect('penjualan/retur/' . $input['d_pj']);
			} else {
				// set_pesan('Opps ada kesalahan!');
				redirect('penjualan/retur/' . $input['d_pj']);
			}
		}
	}

	public function delete($getId)
	{
		$id = encode_php_tags($getId);
		if ($this->admin->delete('penjualan', 'no_po', $id)) {
			$this->admin->delete('penjualan_d', 'd_po', $id);
			set_pesan('data berhasil dihapus.');
		} else {
			set_pesan('data gagal dihapus.', false);
		}
		redirect('penjualan');
	}

	public function del_d($getId)
	{
		$id = encode_php_tags($getId);
		if ($this->admin->delete_d('penjualan_d', ['barang_id' => $id])) {
			// set_pesan('data berhasil dihapus.');
		} else {
			// set_pesan('data gagal dihapus.', false);
		}
		redirect('penjualan/add');
	}

	public function toggle($getId)
	{
		$id = encode_php_tags($getId);
		$status = $this->admin->get('penjualan', ['no_po' => $id])['status'];
		$toggle = $status ? 0 : 1; //Jika user aktif maka nonaktifkan, begitu pula sebaliknya
		$pesan = $toggle ? 'po confirmed.' : 'po on process.';

		if ($this->admin->update('penjualan', 'no_po', $id, ['status' => $toggle])) {
			$this->admin->update('brg_masuk', 'no_po', $id, ['status' => $toggle]);
			set_pesan($pesan);
		}
		redirect('penjualan');
	}

	public function cetak_($id)
	{
		$this->admin->update('penjualan', 'no_notap', $id, ['selesai' => '1']);
		$data = [
			'title' => "Inv-" . $id,
			'data_header' => $this->admin->getPenjualanH0(null, $id),
			'data_detail' => $this->admin->getPenjualanD(null, $id),
			'invoice' => $id,
		];
		$this->load->view('penjualan/print_view', $data);
	}

	public function get_barang_info($barang_id)
	{
		// $barang_id = $this->input->post('barang_id');
		$barang_info = $this->admin->get('barang', ['id_barang' => $barang_id]);
		echo json_encode($barang_info);
		// echo $barang_id;
	}
	
	public function retur($notap)
	{
	    $data['title'] = "Transaksi Retur";
		$data['barang'] = $this->admin->get('barang', null, ['stok >' => '0']);
		$data['voucher'] = $this->admin->get('voucher', null, ['status' => '0', 'tgl_expired >=' => date('Y-m-d')]);
		$data['sales'] = $this->admin->get('sales', null);
		$data['no_notap'] = $notap;

		$data['data_header'] = $this->admin->getPenjualanH0(null, $notap);
		$data['data_detail'] = $this->admin->getPenjualanD(null, $notap);
// 		echo json_encode($data);
		$this->template->load('templates/dashboard', 'penjualan/retur_penjualan', $data);
	}
	
	public function retur_d()
	{
	    $input = $this->input->post(null, true);
	    $insert = $this->admin->insert('retur', $input);
	    $this->admin->delete_d('penjualan_d', ['barang_id' => $input['barang_id'],'d_pj' => $input['d_pj']]);
	   // echo json_encode($input);
	   redirect('penjualan/retur/' . $input['d_pj']);
	}
	
	
// 	customer service dp
    public function addcs()
	{
		$data['title'] = "Transaksi Customer Service";
		$data['barang'] = $this->admin->get('barang', null, ['stok >' => '0']);
		$data['voucher'] = $this->admin->get('voucher', null, ['status' => '0', 'tgl_expired >=' => date('Y-m-d')]);
		$data['sales'] = $this->admin->get('sales', null);
		$data['customer'] = $this->admin->get('customer', null);

		$kode = 'CS'. userdata('id_user').'-';
		$kode_terakhir = $this->admin->getMax('penjualan', 'no_notap', $kode);
		$kode_tambah = substr($kode_terakhir, -4, 4);
		$kode_tambah++;
		$number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
		$data['no_notap'] = $kode . $number;

		$data['data_detail'] = $this->admin->getPenjualanD(null, $kode . $number);
		$this->template->load('templates/dashboard', 'penjualan/add_penjualancs', $data);
	}
	
	public function proses_tcs()
	{
	    $input = $this->input->post(null, true);
	    $input['kd_cs'] = '1';
	    $this->form_validation->set_rules('cust_id', 'Pelanggan', 'required|trim');
	    $this->form_validation->set_rules('subtotal', 'Subtotal', 'required|trim');
        $this->form_validation->set_rules('nego', 'Harga Nego', 'required|trim|numeric|greater_than[-1]|callback_validate_nego');
        $this->form_validation->set_rules('cust_dp', 'Pelanggan DP', 'required|trim');
		$this->_validasi_t();
		if ($this->form_validation->run() == false) {
			$this->addcs();
		} else {
			$insert = $this->admin->insert('penjualan', $input);
			if ($insert) {
				set_pesan('data berhasil disimpan.');
				redirect('penjualan/cust');
			} else {
				set_pesan('Opps ada kesalahan!');
				redirect('transaksics');
			}
		}
	}
	
	public function addcus()
	{
	    $input = $this->input->post(null, true);
	    $this->form_validation->set_rules('nama_cust', 'Nama Pelanggan', 'required|trim');
	    $this->form_validation->set_rules('no_hp', 'No Telp', 'required|trim');
        $this->form_validation->set_rules('alamat', 'Alamat Pelanggan', 'required|trim');
        $this->form_validation->set_rules('jenis_usaha', 'Jenis Usaha', 'required|trim');
		if ($this->form_validation->run() == false) {
			$this->addcs();
		} else {
			$insert = $this->admin->insert('customer', $input);
			if ($insert) {
				set_pesan('data berhasil disimpan.');
				redirect('transaksics');
			} else {
				set_pesan('Opps ada kesalahan!');
				redirect('transaksics');
			}
		}
	}
	
	public function proses_dcs()
	{
	    $input = $this->input->post(null, true);
		$this->_validasi_d();
		if ($this->form_validation->run() == false) {
			$this->addcs();
		} else {
			$insert = $this->admin->insert('penjualan_d', $input);
			if ($insert) {
				// set_pesan('data berhasil disimpan.');
				redirect('transaksics');
			} else {
				// set_pesan('Opps ada kesalahan!');
				redirect('transaksics');
			}
		}
	}
	
	public function cust()
	{
		$data['title'] = "Customer DP";
		if(userdata('role')==='kasir'){
		    $data['datapo'] = $this->admin->getPenjCSDp(null,null,userdata('id_user'));
		}else{
		    $data['datapo'] = $this->admin->getPenjCSDp(null,null,null);
		}
		$data['pnotap'] = $this->admin->get('penjualan', null, ['selesai' => '1']);
		$this->template->load('templates/dashboard', 'penjualan/data_penjualancs', $data);
	}
	
	public function detailcs($id)
	{
		$data['title'] = "Data Cicilan Customer";
		$csid = $this->admin->get('penjualan',['no_notap'=>$id])['cust_id'];
		$data['cicilan'] = $this->admin->get('customer_d', null, ['cs_id' => $csid, 'nota_cs'=> $id]);
		$data['datacs'] = $this->admin->getPenjCSDp(null,$id,null);
// 		echo json_encode($data);
		$this->template->load('templates/dashboard', 'penjualan/data_detailcs', $data);
	}
	
	public function cicilan()
	{
	    $input = $this->input->post(null, true);
// 		echo json_encode($input);
        if($input['aksi']=='tambah'){
            $data = [
    	        'nota_cs' => $input['nota_cs'],
    	        'cs_id' => $input['cs_id'],
    	        'cicilan' => $input['cicilan'],
	        ];
            $insert = $this->admin->insert('customer_d', $data);    
        } else {
            $this->admin->delete('customer_d', 'id_', $input['id_']);
        }
		redirect('penjualan/detailcs/' . $input['nota_cs']);
	}
}
