<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Suratjalan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Surat Jalan";
        $data['data_sj'] = $this->admin->get('suratjalan');
        $this->template->load('templates/dashboard', 'suratjalan/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama', 'Nama Pelanggan', 'required|trim');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
        $this->form_validation->set_rules('tgl_suratjalan', 'Tanggal', 'required|trim');
    }

    public function add()
    {
        $data['title'] = "Surat Jalan";
        $kode = 'SJ-' . date('Y-');
        $kode_terakhir = $this->admin->getMax('suratjalan', 'no_suratjalan', $kode);
        $kode_tambah = substr($kode_terakhir, -4, 4);
        $kode_tambah++;
        $number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
        $data['no_sj'] = $kode . $number;
        $data['barang'] = $this->admin->get('barang', null, ['satuan_id' => 3]);
        $data['data_detail'] = $this->admin->getSuratjalanD(null, $kode . $number);
        $this->template->load('templates/dashboard', 'suratjalan/add', $data);
    }

    public function proses_t()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $this->add();
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('suratjalan', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan.');
                redirect('suratjalan');
            } else {
                set_pesan('Opps ada kesalahan!');
                redirect('suratjalan/add');
            }
        }
    }

    // public function edit($getId)
    // {
    //     $id = encode_php_tags($getId);
    //     $this->_validasi();

    //     if ($this->form_validation->run() == false) {
    //         $data['title'] = "Tanda Terima";
    //         $data['td'] = $this->admin->get('suratjalan', ['id' => $id]);
    //         $this->template->load('templates/dashboard', 'suratjalan/edit', $data);
    //     } else {
    //         $input = $this->input->post(null, true);
    //         $update = $this->admin->update('suratjalan', 'id', $id, $input);
    //         if ($update) {
    //             set_pesan('data berhasil disimpan');
    //             redirect('suratjalan');
    //         } else {
    //             set_pesan('data gagal disimpan', false);
    //             redirect('suratjalan/add');
    //         }
    //     }
    // }

    // validasi detail
    private function _validasi_d()
    {
        $this->form_validation->set_rules('nm_barang', 'Produk', 'required|trim');
        $this->form_validation->set_rules('jumlah', 'Jumlah', 'required|trim|numeric|greater_than[0]');
        // $this->form_validation->set_rules('keterangan', 'Keterangan', 'required|trim');
    }
    public function proses_d()
    {
        $this->_validasi_d();
        if ($this->form_validation->run() == false) {
            $this->add();
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('suratjalan_d', $input);

            if ($insert) {
                // set_pesan('data berhasil disimpan.');
                redirect('suratjalan/add');
            } else {
                // set_pesan('Opps ada kesalahan!');
                redirect('suratjalan/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('suratjalan', 'no_suratjalan', $id)) {
            $this->admin->delete_d('suratjalan_d', ['no_suratjalan' => $id]);
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('suratjalan');
    }

    public function del_d($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete_d('suratjalan_d', ['no_suratjalan' => $id])) {
            // set_pesan('data berhasil dihapus.');
        } else {
            // set_pesan('data gagal dihapus.', false);
        }
        redirect('suratjalan/add');
    }

    public function print_($id)
    {
        $this->load->helper(['tgl_indo']);
        // get data table
        $data = $this->admin->getSuratjalan(null, $id);
        $data1 = $this->admin->getSuratjalanD(null, $id);

        $this->load->library('PDF_MC_Table');

        $this->load->library('PDF_MC_Table');

        $pdf = new PDF_MC_Table();
        $pdf->AddPage('P', 'A4');

        $pdf->SetFont('Arial', '', 13);

        $pdf->Cell(35, 5, ' ', 0, 0);
        $pdf->Image('assets/img/logosksejahtera.jpeg', 10, 10, 30);
        $al = array('Jln Kali Baru Barat 2 A NO:23 RT 003/010, Kel: Kali Baru, Kec: Cilincing Jakarta Utara, Kota Jakarta Utara, DKI Jakarta, Indonesia', 'Telp: +62 858-1352-7166, Email: rmmsupport@sksejahtera.com');

        $pdf->SetWidths(array(150));
        $pdf->SetLineHeight(5);
        $pdf->SetAligns(array('L'));
        // $pdf->SetFont('Arial','',12);

        // $pdf->RowN(array($al[0] . ',' . $al[1]));
        $pdf->RowN(array(implode(PHP_EOL, $al)));
        $pdf->Ln(12);
        $pdf->Cell(190, 5, '', 'B', 0, 0);
        $pdf->Ln(8);
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(190, 5, 'SURAT JALAN', 0, 1, 'C');
        $pdf->Ln();

        $pdf->SetWidths(array(65, 85));
        $pdf->SetLineHeight(5);
        $pdf->SetAligns(array('L', ''));
        $pdf->SetFont('Arial', '', 12);

        foreach ($data as $d) {
            $nn = explode('-', $d['no_suratjalan']);
            $pdf->Cell(35, 5, 'Nama Pelanggan', 0, 0, 'L');
            $pdf->Cell(2, 5, ':', 0, 0, 'L');
            $pdf->RowN(array($d['nama'], 'Nomor      : ' . $nn[0] . '/' . $nn[1] . '/' . $nn[2]));
            $pdf->Cell(35, 5, 'Alamat', 0, 0, 'L');
            $pdf->Cell(2, 5, ':', 0, 0, 'L');
            $pdf->RowN(array($d['alamat'], 'Tanggal    : ' . mediumdate_indo($d['tgl_suratjalan'])));
            $pdf->Ln();
        }

        $pdf->Cell(190, 5, 'Bersama ini kami mengirimkan barang-barang berikut :', 0, 1);
        $pdf->Ln(5);

        $pdf->SetWidths(array(8, 80, 20, 80));
        $pdf->SetLineHeight(5);
        $pdf->SetAligns(array('C', '', 'C', ''));
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(8, 5, 'No', 1, 0);
        $pdf->Cell(80, 5, 'Nama Barang', 1, 0, 'C');
        $pdf->Cell(20, 5, 'Jumlah', 1, 0, 'C');
        $pdf->Cell(80, 5, 'Keterangan', 1, 1, 'C');
        foreach ($data1 as $v) {
            $pdf->SetFont('Arial', '', 12);
            $no = 1;
            $pdf->Row(array(
                $no++,
                $v['nama_barang'],
                $v['jumlah'],
                $v['keterangan']
            ));
        }

        $pdf->Ln(5);
        $pdf->Cell(5, 5, '', 0, 0);
        $pdf->Cell(30, 5, 'Hormat kami,', 0, 0, 'C');
        $pdf->Cell(40, 5, '', 0, 0);
        $pdf->Cell(30, 5, 'Penerima,', 0, 1, 'C');
        $pdf->Ln(30);
        $pdf->Cell(5, 5, '', 0, 0);
        $pdf->Cell(30, 5, '........................', 0, 0, 'C');
        $pdf->Cell(40, 5, '', 0, 0);
        $pdf->Cell(30, 5, '........................', 0, 1, 'C');

        $file_name = $id;
        $pdf->Output('I', $file_name);
    }
}
