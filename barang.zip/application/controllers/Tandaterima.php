<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tandaterima extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Tanda Terima";
        $data['data_t'] = $this->admin->get('tandaterima');
        $this->template->load('templates/dashboard', 'tandaterima/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('dari', 'Dari', 'required|trim');
        $this->form_validation->set_rules('kepada', 'Kepada', 'required|trim');
        $this->form_validation->set_rules('tanggal', 'Hari/Tanggal', 'required|trim');
        $this->form_validation->set_rules('nominal', 'Nominal', 'required|trim|numeric');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Tanda Terima";
            $this->template->load('templates/dashboard', 'tandaterima/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('tandaterima', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('tandaterima');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('tandaterima/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Tanda Terima";
            $data['td'] = $this->admin->get('tandaterima', ['id_tandaterima' => $id]);
            $this->template->load('templates/dashboard', 'tandaterima/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('tandaterima', 'id_tandaterima', $id, $input);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('tandaterima');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('tandaterima/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('tandaterima', 'id_tandaterima', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('tandaterima');
    }

    public function print_($id)
    {
        $this->load->helper(['terbilang','tgl_indo']);
        // get data table
        $data = $this->admin->getTandaterima(null, $id);

        $this->load->library('PDF_MC_Table');

        $pdf = new PDF_MC_Table();
        $pdf->AddPage('L', 'A4');

        $pdf->SetFont('Arial','B',14);

        $pdf->Cell(115 ,5,' ',0,0);
        $pdf->Image('assets/img/logosksejahtera.jpeg', 10, 10, 30);
        $pdf->Ln(20);

        foreach ($data as $b) {
            $pdf->SetFont('Arial','B',18);
            $pdf->Cell(275 ,15,'TANDA TERIMA','B',1,'C');//end of line
            $pdf->Ln(5);
            //summary
            $pdf->SetWidths(Array(222));
            $pdf->SetLineHeight(5);
            $pdf->SetAligns(Array('L'));
            $pdf->SetFont('Arial','',16);

            $pdf->Cell(50 ,5,'Dari',0,0,'L');
            $pdf->Cell(3 ,5,':',0,0,'L');
            $pdf->RowN(Array($b['dari']));
            $pdf->Ln();
            $pdf->Cell(50 ,5,'Kepada',0,0,'L');
            $pdf->Cell(3 ,5,':',0,0,'L');
            $pdf->RowN(Array($b['kepada']));
            $pdf->Ln();
            $pdf->Cell(50 ,5,'Hari/Tanggal',0,0,'L');
            $pdf->Cell(3 ,5,':',0,0,'L');
            $pdf->RowN(Array(longdate_indo($b['tanggal'])));
            $pdf->Ln();
            $pdf->Cell(50 ,5,'Nomilal',0,0,'L');
            $pdf->Cell(3 ,5,':',0,0,'L');
            $pdf->RowN(Array(number_format($b['nominal'],0,',','.')));
            $pdf->Ln();
            $pdf->Cell(50 ,5,'Terbilang',0,0,'L');
            $pdf->Cell(3 ,5,':',0,0,'L');
            $pdf->RowN(Array( ucfirst(terbilang($b['nominal']))));
            $pdf->Ln();
            $pdf->Cell(50 ,5,'Keterangan',0,0,'L');
            $pdf->Cell(3 ,5,':',0,0,'L');
            $pdf->RowN(Array($b['keterangan']));
            $pdf->Ln();

            $pdf->Cell(275 ,5,'','B',1,'C');//end of line
            $pdf->Ln();

            $pdf->Cell(30 ,5,'',0,0);
            $pdf->Cell(50 ,5,'Yang menyerahkan,',0,0,'C');
            $pdf->Cell(100 ,5,'',0,0);
            $pdf->Cell(50 ,5,'Yang menerima,',0,1,'C');
            $pdf->Ln(30);
            $pdf->Cell(30 ,5,'',0,0);
            $pdf->Cell(50 ,5,'........................',0,0,'C');
            $pdf->Cell(100 ,5,'',0,0);
            $pdf->Cell(50 ,5,'........................',0,1,'C');
            
        }

        $file_name = $id;
        $pdf->Output('I', $file_name);
    }
}
