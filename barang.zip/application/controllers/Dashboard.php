<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
    }

    public function index()
    {
        $dataBar = $this->admin->get('penjualan');
        $transformed_data = [];
        
        // Get the current year
        $current_year = date('Y');
        
        // Generate an array with the names of all 12 months for the current year
        $all_months = [];
        for ($month = 1; $month <= 12; $month++) {
            $month_name = date('F', mktime(0, 0, 0, $month, 1, $current_year));
            $all_months[] = $month_name;
        }
        
        foreach ($all_months as $month) {
            $transformed_data[$month] = 0;
        }
        
        foreach ($dataBar as $row) {
            $date = DateTime::createFromFormat('Y-m-d', $row['tanggal_']);
            $month = $date->format('F');
            if (!isset($transformed_data[$month])) {
                $transformed_data[$month] = 0;
            }
            $transformed_data[$month] += $row['grandtotal'];
        }
        
        $data['barChart'] = $transformed_data;
        
        $data['title'] = "Dashboard";
		$data['brg_min'] = $this->admin->getBarangMin();
		$data['brg_max'] = $this->admin->getBarangMax();
        // $data['barang'] = $this->admin->count('barang');
        // $data['barang_masuk'] = $this->admin->count('barang_masuk');
        // $data['barang_keluar'] = $this->admin->count('barang_keluar');
        // $data['supplier'] = $this->admin->count('supplier');
        // $data['user'] = $this->admin->count('user');
        // $data['stok'] = $this->admin->sum1('barang', 'stok');
        // $data['stok2'] = $this->admin->sum2('barang', 'stok');
        // $data['barang_min'] = $this->admin->getBarang();
        // $data['tempo'] = $this->admin->get('po_invoice',null,['tanggal_tempo < ' => date('Y-m-d'),'status'=>0]);
        // $data['transaksi'] = [
        //     'barang_masuk' => $this->admin->getBarangMasuk(30),
        //     'barang_keluar' => $this->admin->getBarangKeluar(30),
        //     'barang_west' => $this->admin->getBarangWest(30)
        // ];

        $this->template->load('templates/dashboard', 'dashboard', $data);
    }
}
