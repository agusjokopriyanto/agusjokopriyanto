<?php
defined('BASEPATH') or exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\IOFactory;

class Kategori extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		cek_login();

		$this->load->model('Admin_model', 'admin');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$data['title'] = "Kategori";
		$data['kategori'] = $this->admin->get('kategori');
		$this->template->load('templates/dashboard', 'kategori/data', $data);
	}

	private function _validasi()
	{
		$this->form_validation->set_rules('kd_kategori', 'Kode kategori', 'required|trim');
		$this->form_validation->set_rules('nama_kategori', 'Nama kategori', 'required|trim');
	}

	public function add()
	{
		$this->_validasi();

		if ($this->form_validation->run() == false) {
			$data['title'] = "Kategori";
			$this->template->load('templates/dashboard', 'kategori/add', $data);
		} else {
			$input = $this->input->post(null, true);
			$insert = $this->admin->insert('kategori', $input);
			if ($insert) {
				set_pesan('data berhasil disimpan');
				redirect('kategori');
			} else {
				set_pesan('data gagal disimpan', false);
				redirect('kategori/add');
			}
		}
	}

	public function edit($getId)
	{
		$id = encode_php_tags($getId);
		$this->_validasi();

		if ($this->form_validation->run() == false) {
			$data['title'] = "Kategori";
			$data['kategori'] = $this->admin->get('kategori', ['id_kategori' => $id]);
			$this->template->load('templates/dashboard', 'kategori/edit', $data);
		} else {
			$input = $this->input->post(null, true);
			$update = $this->admin->update('kategori', 'id_kategori', $id, $input);
			if ($update) {
				set_pesan('data berhasil disimpan');
				redirect('kategori');
			} else {
				set_pesan('data gagal disimpan', false);
				redirect('kategori/add');
			}
		}
	}

	public function delete($getId)
	{
		$id = encode_php_tags($getId);
		if ($this->admin->delete('kategori', 'id_kategori', $id)) {
			set_pesan('data berhasil dihapus.');
		} else {
			set_pesan('data gagal dihapus.', false);
		}
		redirect('kategori');
	}
	
	function import_excel()
	{
        $this->load->helper('file');

        /* Allowed MIME(s) File */
        $file_mimes = array(
            'application/octet-stream', 
            'application/vnd.ms-excel', 
            'application/x-csv', 
            'text/x-csv', 
            'text/csv', 
            'application/csv', 
            'application/excel', 
            'application/vnd.msexcel', 
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );

        if(isset($_FILES['uploadFile']['name']) && in_array($_FILES['uploadFile']['type'], $file_mimes)) {

            $array_file = explode('.', $_FILES['uploadFile']['name']);
            $extension  = end($array_file);

            if('csv' == $extension) {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            } else if('xls' == $extension) {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            }

            $spreadsheet = $reader->load($_FILES['uploadFile']['tmp_name']);
            $sheet_data  = $spreadsheet->getActiveSheet(0)->toArray();
            $array_data  = [];

            for($i = 1; $i < count($sheet_data); $i++) {
                $data = array(
                    'kd_kategori'       => $sheet_data[$i]['0'],
                    'nama_kategori'      => $sheet_data[$i]['1']
                );
                $array_data[] = $data;
            }
            
            if($array_data != '') {
                $this->db->insert_batch('kategori',$array_data);
            }
            // $this->modal_feedback('success', 'Success', 'Data Imported', 'OK');
        } else {
            // $this->modal_feedback('error', 'Error', 'Import failed', 'Try again');
        }
        redirect('kategori');
    }
}
