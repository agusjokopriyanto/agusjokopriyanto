<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Purchaseorder extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "PURCHASE ORDER";
        $data['datapo'] = $this->admin->getPOSup(null,null);
        $this->template->load('templates/dashboard', 'purchase_order/data_po', $data);
    }

    public function add()
    {
        $data['title'] = "Tambah Purchase Order";
        $data['barang'] = $this->admin->get('barang',null);
		$data['supplier'] = $this->admin->get('supplier',null);

        $kode = 'PO'. userdata('id_user').'-';
        $kode_terakhir = $this->admin->getMax('purchase_order', 'no_po', $kode);
        $kode_tambah = substr($kode_terakhir, -4, 4);
        $kode_tambah++;
        $number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
        $data['no_po'] = $kode . $number;

        $data['data_detail'] = $this->admin->getPurchaseorderD(null, $kode . $number);
        $this->template->load('templates/dashboard', 'purchase_order/add_po', $data);
    }

    // validasi top invoice
    private function _validasi_t()
    {
        $this->form_validation->set_rules('supplier_id', 'Supplier', 'required|trim');
    }

    public function proses_t()
    {
        $this->_validasi_t();
        if ($this->form_validation->run() == false) {
            $this->add();
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('purchase_order', $input);
			$insert = $this->admin->insert('brg_masuk', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan.');
                redirect('purchaseorder');
            } else {
                set_pesan('Opps ada kesalahan!');
                redirect('purchaseorder/add');
            }
        }
    }

    // validasi detail invoice
    private function _validasi_d()
    {
        $this->form_validation->set_rules('barang_id', 'Produk', 'required|trim');
        $this->form_validation->set_rules('qty', 'Quantity', 'required|trim|numeric|greater_than[0]');
		$this->form_validation->set_rules('grade', 'Grade', 'required|trim');
    }
    // proses detail invoice
    public function proses_d()
    {
        $this->_validasi_d();
        if ($this->form_validation->run() == false) {
            $this->add();
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('purchase_order_d', $input);
			$insert = $this->admin->insert('brg_masuk_d', $input);

            if ($insert) {
                // set_pesan('data berhasil disimpan.');
                redirect('purchaseorder/add');
            } else {
                // set_pesan('Opps ada kesalahan!');
                redirect('purchaseorder/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('purchase_order', 'no_po', $id)) {
            $this->admin->delete('purchase_order_d', 'd_po', $id);
			$this->admin->delete('brg_masuk', 'no_po', $id);
			$this->admin->delete('brg_masuk_d', 'd_po', $id);
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('purchaseorder');
    }

    public function del_d($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete_d('purchase_order_d', ['d_po'=> $id])) {
            $this->admin->delete_d('brg_masuk_d', ['d_po'=> $id]);
			// set_pesan('data berhasil dihapus.');
        } else {
            // set_pesan('data gagal dihapus.', false);
        }
        redirect('purchaseorder/add');
    }

    public function print_($id)
    {
        // get data table
        $data = $this->admin->getPurchaseorder(null, $id);
        $dat2 = $this->admin->getPurchaseorderD(null, $id);

        $this->load->library('PDF_MC_Table');

        $pdf = new PDF_MC_Table();
        $pdf->AddPage('P', 'A4');

        $pdf->SetFont('Arial','B',14);

        $pdf->Cell(115 ,5,' ',0,0);
        $pdf->Image('assets/img/logosksejahtera.jpeg', 10, 10, 30);
        $pdf->Cell(74 ,5,'Purchase Order',0,1,'R');//end of line
        $pdf->Ln(3);

        $pdf->SetFont('Arial','',12);

        foreach ($data as $d) {
            $noinv = explode('-',$d['no_po']);
            $nama = explode(':',$d['data']);

            $nm = array('CV. Ryo Multi Makmur',$nama[0]);
            $al = array('Jln Kali Baru Barat 2 A NO:23 RT 003/010, '."\n".'Kel: Kali Baru, Kec: Cilincing Jakarta Utara, '."\n".'Kota Jakarta Utara, DKI Jakarta, Indonesia',$nama[1]);
            $tp = array('Telp: +62 858-1352-7166',$nama[2]);
            $em = array('Email: rmmsupport@sksejahtera.com',$nama[3]);

            $pdf->Cell(115 ,5,' ',0,0);
            $pdf->Cell(36 ,5,'Referensi',0,0,'R');
            $pdf->Cell(38 ,5,$noinv[0].'/'.$noinv[1].'/'.$noinv[2],0,1,'R');//end of line

            $pdf->Cell(115 ,5,' ',0,0);
            $pdf->Cell(36 ,5,'Tanggal',0,0,'R');
            $date = date_create($d['tanggal_']);
            $pdf->Cell(38 ,5,date_format($date,"d/m/Y"),0,1,'R');//end of line

            $pdf->Cell(115 ,5,' ',0,0);
            $pdf->Cell(36 ,5,'Status',0,0,'R');
            if($d['status']==0){
                $st='On Process';
            }else{
                $st='Confirmed';
            }
            $pdf->SetFont('Arial','B',12);
            $pdf->Cell(38 ,5,$st,0,1,'R');//end of line

            $pdf->SetFont('Arial','',12);
            $pdf->Cell(115 ,5,' ',0,0);
            $pdf->Cell(36 ,5,'No.NPWP',0,0,'R');
            $pdf->Cell(38 ,5,'355391301416000',0,1,'R');//end of line
            $pdf->Ln(4);
            $pdf->Line(10,41,199,41);

            $pdf->SetWidths(Array(99,90));
            $pdf->SetLineHeight(5);
            $pdf->SetAligns(Array('',''));
            $pdf->SetFont('Arial','B',12);
            $pdf->Cell(99 ,5,'Info Perusahaan',0,0);
            $pdf->Cell(90 ,5,'Tagihan Untuk',0,1);//end of line
            $pdf->Ln(3);
            $pdf->Line(10,48,199,48);

            $pdf->SetFont('Arial','',12);
            $pdf->RowN(Array($nm[0], $nm[1]));
            $pdf->RowN(Array($al[0], $al[1]));
            $pdf->RowN(Array($tp[0], 'Telp: '.$tp[1]));
            $pdf->RowN(Array($em[0], 'Email: '.$em[1]));
            $pdf->Ln();
        }

        $pdf->SetWidths(Array(65,15,25,15,25,44));
        $pdf->SetLineHeight(5);
        $pdf->SetAligns(Array('','R','R','R','C','R'));
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(65 ,5,'Produk',1,0);
        $pdf->Cell(15 ,5,'Qty',1,0,'C');
        $pdf->Cell(25 ,5,'Harga',1,0,'C');
        $pdf->Cell(15 ,5,'Disc',1,0,'C');
        $pdf->Cell(25 ,5,'Pajak',1,0,'C');
        $pdf->Cell(44 ,5,'Jumlah',1,1,'C');//end of line

        $pdf->SetFont('Arial','',12);
        foreach ($dat2 as $v) {
            $pdf->Row(Array(
              $v['nama_barang'].' - '.$v['deskripsi'],
              $v['qty'],
              number_format($v['harga_d'],2,',','.'),
              $v['diskon'].' %',
              $v['pajak_d'].' %',
              number_format($v['jumlah_d'],2,',','.')
          ));
        }
        $pdf->Ln();

        foreach ($data as $b) {
            //summary
            $pdf->Cell(94 ,5,'',0,0);
            $pdf->Cell(25 ,5,'Subtotal',0,0,'R');
            $pdf->Cell(70 ,5,'Rp '. number_format($b['subtotal'],2,',','.'),0,1,'R');//end of line

            $pdf->Cell(94 ,5,'',0,0);
            $pdf->Cell(25 ,5,'Total Diskon',0,0,'R');
            $pdf->Cell(70 ,5,'Rp '. '('.number_format($b['total_diskon'],2,',','.').')',0,1,'R');//end of line

            $pdf->Cell(94 ,5,'',0,0);
            $pdf->Cell(25 ,5,'Diskon Tambahan',0,0,'R');
            $pdf->Cell(70 ,5,'Rp '. number_format($b['diskon_tambah']/100*$b['subtotal'],2,',','.'),0,1,'R');//end of line

            $pdf->Cell(94 ,5,'',0,0);
            $pdf->Cell(25 ,5,'Pajak',0,0,'R');
            $pdf->Cell(70 ,5,'Rp '. number_format($b['pajak'],2,',','.'),0,1,'R');//end of line

            $pdf->Cell(94 ,5,'',0,0);
            $pdf->Cell(25 ,5,'Total',0,0,'R');
            $pdf->Cell(70 ,5,'Rp '. number_format($b['total'],2,',','.'),0,1,'R');//end of line

            $pdf->Cell(74 ,5,'',0,0);
            $pdf->Cell(45 ,7,'Pajak Inclusive '.$b['pajak_inc'].'%','B',0,'R');
            $cc = ((100/(100 + $b['pajak_inc'])) * $b['total'])*$b['pajak_inc']/100;
            $pdf->Cell(70 ,7,'Rp '. number_format($cc,2,',','.'),'B',1,'R');//end of line

            $pdf->Ln(2);
            $pdf->Cell(94 ,5,'',0,0);
            $pdf->Cell(25 ,5,'Jumlah Tertagih:',0,0,'R');
            $pdf->Cell(70 ,5,'Rp '. number_format($b['jumlah_tagihan'],2,',','.'),0,1,'R');//end of line
            $pdf->Ln(3);

            $ket = array(
                'Terima kasih atas kepercayaan anda',
                'Purchase order akan di terima jika sudah melalukan full payment',
                'Simpan bukti purchase order ini sebagai bukti yang SAH.',
                'Pembayaran di lakukan ke Account Rek BCA 4140474440 a/n HARYONO'
            );

            $pdf->SetFont('Arial','B',12);
            $pdf->Cell(99, 10, 'Keterangan', 'B', 1);
            $pdf->Ln(2);
            $pdf->SetFont('Arial','',12);
            $pdf->Cell(99, 5, $ket[0], 0, 1);
            $pdf->Ln();

            $pdf->SetWidths(Array(6,93));
            $pdf->SetLineHeight(5);
            $pdf->SetAligns(Array('',''));
            $pdf->SetFont('Arial','B',12);
            $pdf->Cell(99, 10, 'Syarat & Ketentuan', 'B', 1);
            $pdf->Ln(2);

            $pdf->SetFont('Arial','I',12);
            $pdf->Cell(99, 5, 'Paymet Metode ;', 0, 1);
            $pdf->Ln(2);
            $pdf->RowN(Array('1.',$ket[1]));
            $pdf->RowN(Array('2.',$ket[2]));
            $pdf->RowN(Array('3.',$ket[3]));
            $pdf->Ln();

            $pdf->SetFont('Arial','',12);
            $date = date_create($b['tanggal_']);
            $pdf->Cell(130 ,5,'',0,0);
            $pdf->Cell(25 ,5,date_format($date,"j M, Y"),0,1,'C');
            $pdf->Ln(20);
            $pdf->Cell(130 ,5,'',0,0);
            $pdf->Cell(25 ,5,'Finance',0,1,'C');//end of line
        }

        $file_name = $id;
        $pdf->Output('I', $file_name);
    }

    public function toggle($getId)
    {
        $id = encode_php_tags($getId);
        $status = $this->admin->get('purchase_order', ['no_po' => $id])['status'];
        $toggle = $status ? 0 : 1; //Jika user aktif maka nonaktifkan, begitu pula sebaliknya
        $pesan = $toggle ? 'po confirmed.' : 'po on process.';

        if ($this->admin->update('purchase_order', 'no_po', $id, ['status' => $toggle])) {
            $this->admin->update('brg_masuk', 'no_po', $id, ['status' => $toggle]);
			set_pesan($pesan);
        }
        redirect('purchaseorder');
    }
    
    function import_excel()
	{
        $this->load->helper('file');

        /* Allowed MIME(s) File */
        $file_mimes = array(
            'application/octet-stream', 
            'application/vnd.ms-excel', 
            'application/x-csv', 
            'text/x-csv', 
            'text/csv', 
            'application/csv', 
            'application/excel', 
            'application/vnd.msexcel', 
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );

        if(isset($_FILES['uploadFile']['name']) && in_array($_FILES['uploadFile']['type'], $file_mimes)) {

            $array_file = explode('.', $_FILES['uploadFile']['name']);
            $extension  = end($array_file);

            if('csv' == $extension) {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            } else if('xls' == $extension) {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            }

            $spreadsheet = $reader->load($_FILES['uploadFile']['tmp_name']);
            $sheet_data  = $spreadsheet->getActiveSheet(0)->toArray();
            $array_data  = [];

            for($i = 1; $i < count($sheet_data); $i++) {
                $data = array(
                    'd_po'      => $sheet_data[$i]['0'],
                    'barang_id' => $sheet_data[$i]['1'],
                    'qty'       => $sheet_data[$i]['2'],
                    'grade'     => $sheet_data[$i]['3']
                );
                $array_data[] = $data;
            }
            
            if($array_data != '') {
                $this->db->insert_batch('purchase_order_d',$array_data);
                $this->db->insert_batch('brg_masuk_d',$array_data);
            }
            // $this->modal_feedback('success', 'Success', 'Data Imported', 'OK');
        } else {
            // $this->modal_feedback('error', 'Error', 'Import failed', 'Try again');
        }
        redirect('purchaseorder/add');
    }
}
