<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		cek_login();

		$this->load->model('Admin_model', 'admin');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->form_validation->set_rules('transaksi', 'Transaksi', 'required|in_list[brg_masuk,penjualan,barang_broken,sales,retur]');
		$this->form_validation->set_rules('tanggal', 'Periode Tanggal', 'required');

		if ($this->form_validation->run() == false) {
			$data['title'] = "Laporan Transaksi";
			$data['sales'] = $this->admin->get('sales', null);
			$this->template->load('templates/dashboard', 'laporan/form', $data);
		} else {
			$this->_cetak();
		}
	}

	public function _cetak()
	{
		$input = $this->input->post(null, true);
		$dateParts = explode(' - ', $input['tanggal']);
		$startDate = trim($dateParts[0]); // Remove leading/trailing spaces
		$endDate = trim($dateParts[1]);
		$awal = DateTime::createFromFormat('m/d/Y', $startDate)->format('Y-m-d');
		$akhir =  DateTime::createFromFormat('m/d/Y', $endDate)->format('Y-m-d');

		if ($input['transaksi'] == 'penjualan') {
			$data = [
				'title' => "Laporan Penjualan",
				'range' => $startDate . ' s/d ' . $endDate,
				'data_header' => $this->db
					->select('penjualan.*, user.nama, voucher.nominal, sales.nama_sales')
					->from('penjualan')
					->where('penjualan.selesai', '1')
					->where('penjualan.tanggal_ >=', $awal)
					->where('penjualan.tanggal_ <=', $akhir)
					->join('user', 'user.id_user = penjualan.user_id', 'left')
					->join('sales', 'sales.id_sales = penjualan.sales_id', 'left')
					->join('voucher', 'voucher.kd_voucher = penjualan.voucher', 'left')
					->order_by('penjualan.tanggal_', 'ASC')
					->get()
					->result_array(),
			];
// 			echo json_encode($data);
			$this->load->view('laporan/lap_view_pj', $data);
		} else if ($input['transaksi'] == 'brg_masuk') {
			$data = [
				'title' => "Laporan Barang Masuk",
				'range' => $startDate . ' s/d ' . $endDate,
				'data_header' => $this->db
					->select('brg_masuk.*, supplier.nama_supplier')
					->from('brg_masuk')
					->where('brg_masuk.tanggal_bm >=', $awal)
					->where('brg_masuk.tanggal_bm <=', $akhir)
					->join('supplier', 'supplier.id_supplier = brg_masuk.supplier_id', 'left')
					->order_by('brg_masuk.tanggal_bm', 'ASC')
					->get()
					->result_array(),
			];
			// echo json_encode($data);
			$this->load->view('laporan/lap_view_bm', $data);
		} else if ($input['transaksi'] == 'barang_broken') {
			$data = [
				'title' => "Laporan Barang Broken",
				'range' => $startDate . ' s/d ' . $endDate,
				'data_header' => $this->db
					->select('barang_broken.*')
					->from('barang_broken')
					->where('barang_broken.tanggal_ >=', $awal)
					->where('barang_broken.tanggal_ <=', $akhir)
					->order_by('barang_broken.tanggal_', 'ASC')
					->get()
					->result_array(),
			];
			// echo json_encode($data);
			$this->load->view('laporan/lap_view_bkn', $data);
		} else if ($input['transaksi'] == 'sales') {
			$data = [
				'title' => "Laporan Sales",
				'range' => $startDate . ' s/d ' . $endDate,
				'awal'  => $awal,
				'akhir' => $akhir,
				'data_header' => $this->db
					->select('sales.*')
					->from('sales')
					->where('sales.id_sales', $input['sales_id'])
					->get()
					->result_array(),
			];
// 			echo json_encode($data);
			$this->load->view('laporan/lap_view_sls', $data);
		} else if ($input['transaksi'] == 'retur') {
			$data = [
				'title' => "Laporan Barang Retur",
				'range' => $startDate . ' s/d ' . $endDate,
				'data_header' => $this->db
					->select('retur.*,barang.nama_barang')
					->from('retur')
					->where('retur.create_at >=', $awal)
					->where('retur.create_at <=', $akhir)
					->join('barang', 'barang.id_barang = retur.barang_id', 'left')
					->order_by('retur.create_at', 'ASC')
					->get()
					->result_array(),
			];
// 			echo json_encode($data);
			$this->load->view('laporan/lap_view_rtr', $data);
		} else {
			# code...
		}
	}

}
