<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Barangbroken extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		cek_login();

		$this->load->model('Admin_model', 'admin');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$data['title'] = "Barang Broken";
		$data['datapo'] = $this->admin->get('barang_broken', null);
		$this->template->load('templates/dashboard', 'barang_broken/data_bkn', $data);
	}

	public function add()
	{
		$data['title'] = "Tambah Barang Broken";
		$data['barang'] = $this->admin->get('barang', null, ['stok >' => '0']);

		$kode = 'BK'. userdata('id_user').'-';
		$kode_terakhir = $this->admin->getMax('barang_broken', 'no_po', $kode);
		$kode_tambah = substr($kode_terakhir, -4, 4);
		$kode_tambah++;
		$number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
		$data['no_po'] = $kode . $number;

		$data['data_detail'] = $this->admin->getbarangbrokenD(null, $kode . $number);
		$this->template->load('templates/dashboard', 'barang_broken/add_bkn', $data);
	}

	// validasi top invoice
	private function _validasi_t()
	{
		$this->form_validation->set_rules('supplier_id', 'Supplier', 'required|trim');
	}

	public function proses_t()
	{
		// $this->_validasi_t();
		// if ($this->form_validation->run() == false) {
		//     $this->add();
		// } else {
		$input = $this->input->post(null, true);
		$insert = $this->admin->insert('barang_broken', $input);

		if ($insert) {
			set_pesan('data berhasil disimpan.');
			redirect('barangbroken');
		} else {
			set_pesan('Opps ada kesalahan!');
			redirect('barangbroken/add');
		}
		// }
	}

	// validasi detail invoice
	private function _validasi_d()
	{
		$this->form_validation->set_rules('barang_id', 'Produk', 'required|trim');
		$this->form_validation->set_rules('qty_bkn', 'Quantity', 'required|trim|numeric|greater_than[0]');
		$this->form_validation->set_rules('harga_j', 'Harga', 'required|trim');
	}
	// proses detail invoice
	public function proses_d()
	{
		$this->_validasi_d();
		if ($this->form_validation->run() == false) {
			$this->add();
		} else {
			$input = $this->input->post(null, true);
			// echo json_encode($input);
			$insert = $this->admin->insert('barang_broken_d', $input);

			if ($insert) {
				// set_pesan('data berhasil disimpan.');
				redirect('barangbroken/add');
			} else {
				// set_pesan('Opps ada kesalahan!');
				redirect('barangbroken/add');
			}
		}
	}

	public function delete($getId)
	{
		$id = encode_php_tags($getId);
		if ($this->admin->delete('barang_broken', 'no_po', $id)) {
			$this->admin->delete('barang_broken_d', 'd_po', $id);
			set_pesan('data berhasil dihapus.');
		} else {
			set_pesan('data gagal dihapus.', false);
		}
		redirect('barangbroken');
	}

	public function del_d($getId)
	{
		$id = encode_php_tags($getId);
		if ($this->admin->delete_d('barang_broken_d', ['d_po' => $id])) {
			// set_pesan('data berhasil dihapus.');
		} else {
			// set_pesan('data gagal dihapus.', false);
		}
		redirect('barangbroken/add');
	}

	public function toggle($getId)
	{
		$id = encode_php_tags($getId);
		$status = $this->admin->get('barang_broken', ['no_po' => $id])['status'];
		$toggle = $status ? 0 : 1; //Jika user aktif maka nonaktifkan, begitu pula sebaliknya
		$pesan = $toggle ? 'po confirmed.' : 'po on process.';

		if ($this->admin->update('barang_broken', 'no_po', $id, ['status' => $toggle])) {
			set_pesan($pesan);
		}
		redirect('barangbroken');
	}
	
	public function lihat($id)
	{
		$data['barang'] = $this->admin->get('barang', null);
		$data['barang_broken'] = $this->admin->get('barang_broken', ['no_po' => $id]);
		$data['data_detail'] = $this->admin->getbarangbrokenD(null, $id);
		$data['title'] = $id.' | '.$data['barang_broken']['tanggal_'];
		$this->template->load('templates/dashboard', 'barang_broken/lihat_bkn', $data);
	}
	
	function import_excel()
	{
        $this->load->helper('file');

        /* Allowed MIME(s) File */
        $file_mimes = array(
            'application/octet-stream', 
            'application/vnd.ms-excel', 
            'application/x-csv', 
            'text/x-csv', 
            'text/csv', 
            'application/csv', 
            'application/excel', 
            'application/vnd.msexcel', 
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );

        if(isset($_FILES['uploadFile']['name']) && in_array($_FILES['uploadFile']['type'], $file_mimes)) {

            $array_file = explode('.', $_FILES['uploadFile']['name']);
            $extension  = end($array_file);

            if('csv' == $extension) {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            } else if('xls' == $extension) {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            }

            $spreadsheet = $reader->load($_FILES['uploadFile']['tmp_name']);
            $sheet_data  = $spreadsheet->getActiveSheet(0)->toArray();
            $array_data  = [];

            for($i = 1; $i < count($sheet_data); $i++) {
                $data = array(
                    'd_po'      => $sheet_data[$i]['0'],
                    'barang_id' => $sheet_data[$i]['1'],
                    'qty_bkn'   => $sheet_data[$i]['2'],
                    'harga_j'   => $sheet_data[$i]['3']
                );
                $array_data[] = $data;
            }
            
            if($array_data != '') {
                $this->db->insert_batch('barang_broken_d',$array_data);
            }
            // $this->modal_feedback('success', 'Success', 'Data Imported', 'OK');
        } else {
            // $this->modal_feedback('error', 'Error', 'Import failed', 'Try again');
        }
        redirect('barangbroken/add');
    }
}
