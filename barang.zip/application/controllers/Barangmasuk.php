<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Barangmasuk extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		cek_login();

		$this->load->model('Admin_model', 'admin');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$data['title'] = "Barang Masuk";
		$data['databm'] = $this->admin->getBMSup(null, null);
		$this->template->load('templates/dashboard', 'brg_masuk/data_bm', $data);
	}

	public function edit($id)
	{
		$data['title'] = "Edit Barang Masuk";
		$data['barang'] = $this->admin->get('barang', null);
		$data['supplier'] = $this->admin->get('supplier', null);
		$data['barang_masuk'] = $this->admin->get('brg_masuk', ['no_po' => $id]);
		$data['data_detail'] = $this->admin->getBMD(null, $id);
		$this->template->load('templates/dashboard', 'brg_masuk/edit_bm', $data);
	}

	// validasi top invoice
	private function _validasi_t()
	{
		$this->form_validation->set_rules('tanggal_bm', 'Tanggal Barang Masuk', 'required|trim');
	}

	public function proses_t()
	{
		$input = $this->input->post(null, true);
		$this->_validasi_t();
		if ($this->form_validation->run() == false) {
			redirect('barangmasuk/edit/' . $input['no_po']);
		} else {

			$update = $this->admin->update('brg_masuk', 'no_po', $input['no_po'], $input);

			if ($update) {
				set_pesan('data berhasil disimpan.');
				redirect('barangmasuk');
			} else {
				set_pesan('Opps ada kesalahan!');
				redirect('barangmasuk/edit/' . $input['no_po']);
			}
		}
	}

	// validasi detail invoice
	private function _validasi_d()
	{
		$this->form_validation->set_rules('qty', 'Quantity', 'required|trim|numeric|greater_than[0]');
		$this->form_validation->set_rules('harganet', 'Harga Net', 'required|trim|numeric|greater_than[0]');
		$this->form_validation->set_rules('price', 'Price', 'required|trim|numeric');
		$this->form_validation->set_rules('grade', 'Grade', 'required|trim');
		$this->form_validation->set_rules('harga', 'Harga', 'required|trim|numeric|greater_than[0]');
		$this->form_validation->set_rules('kd_lokasi', 'Kode Lokasi', 'required|trim');
	}
	// proses detail invoice
	public function proses_d()
	{
		$input = $this->input->post(null, true);
		$this->_validasi_d();
		if ($this->form_validation->run() == false) {
			redirect('barangmasuk/edit/' . $input['d_po']);
		} else {
			// $input = $this->input->post(null, true);
			$this->admin->delete_d('brg_masuk_d', ['barang_id' => $input['barang_id'], 'd_po' => $input['d_po']]);
			$insert = $this->admin->insert('brg_masuk_d', $input);

			if ($insert) {
				set_pesan('data berhasil disimpan.');
				redirect('barangmasuk/edit/' . $input['d_po']);
			} else {
				set_pesan('Opps ada kesalahan!');
				redirect('barangmasuk/edit/' . $input['d_po']);
			}
		}
	}

	public function delete($getId)
	{
		$id = encode_php_tags($getId);
		if ($this->admin->delete('brg_masuk', 'no_po', $id)) {
			$this->admin->delete('brg_masuk_d', 'd_po', $id);
			$this->admin->delete('purchase_order', 'no_po', $id);
			$this->admin->delete('purchase_order_d', 'd_po', $id);
			set_pesan('data berhasil dihapus.');
		} else {
			set_pesan('data gagal dihapus.', false);
		}
		redirect('barangmasuk');
	}

	public function del_d($getId, $getId2)
	{
		$id = encode_php_tags($getId);
		$id2 = encode_php_tags($getId2);
		if ($this->admin->delete_d('brg_masuk_d', ['barang_id' => $id, 'd_po' => $id2])) {
			set_pesan('data berhasil dihapus.');
		} else {
			set_pesan('data gagal dihapus.', false);
		}
		redirect('barangmasuk/edit/' . $id2);
	}

	public function print_($id)
	{
		// get data table
		$data = $this->admin->getbarangmasuk(null, $id);
		$dat2 = $this->admin->getbarangmasukD(null, $id);

		$this->load->library('PDF_MC_Table');

		$pdf = new PDF_MC_Table();
		$pdf->AddPage('P', 'A4');

		$pdf->SetFont('Arial', 'B', 14);

		$pdf->Cell(115, 5, ' ', 0, 0);
		$pdf->Image('assets/img/logosksejahtera.jpeg', 10, 10, 30);
		$pdf->Cell(74, 5, 'Purchase Order', 0, 1, 'R'); //end of line
		$pdf->Ln(3);

		$pdf->SetFont('Arial', '', 12);

		foreach ($data as $d) {
			$noinv = explode('-', $d['no_po']);
			$nama = explode(':', $d['data']);

			$nm = array('CV. Ryo Multi Makmur', $nama[0]);
			$al = array('Jln Kali Baru Barat 2 A NO:23 RT 003/010, ' . "\n" . 'Kel: Kali Baru, Kec: Cilincing Jakarta Utara, ' . "\n" . 'Kota Jakarta Utara, DKI Jakarta, Indonesia', $nama[1]);
			$tp = array('Telp: +62 858-1352-7166', $nama[2]);
			$em = array('Email: rmmsupport@sksejahtera.com', $nama[3]);

			$pdf->Cell(115, 5, ' ', 0, 0);
			$pdf->Cell(36, 5, 'Referensi', 0, 0, 'R');
			$pdf->Cell(38, 5, $noinv[0] . '/' . $noinv[1] . '/' . $noinv[2], 0, 1, 'R'); //end of line

			$pdf->Cell(115, 5, ' ', 0, 0);
			$pdf->Cell(36, 5, 'Tanggal', 0, 0, 'R');
			$date = date_create($d['tanggal_']);
			$pdf->Cell(38, 5, date_format($date, "d/m/Y"), 0, 1, 'R'); //end of line

			$pdf->Cell(115, 5, ' ', 0, 0);
			$pdf->Cell(36, 5, 'Status', 0, 0, 'R');
			if ($d['status'] == 0) {
				$st = 'On Process';
			} else {
				$st = 'Confirmed';
			}
			$pdf->SetFont('Arial', 'B', 12);
			$pdf->Cell(38, 5, $st, 0, 1, 'R'); //end of line

			$pdf->SetFont('Arial', '', 12);
			$pdf->Cell(115, 5, ' ', 0, 0);
			$pdf->Cell(36, 5, 'No.NPWP', 0, 0, 'R');
			$pdf->Cell(38, 5, '355391301416000', 0, 1, 'R'); //end of line
			$pdf->Ln(4);
			$pdf->Line(10, 41, 199, 41);

			$pdf->SetWidths(array(99, 90));
			$pdf->SetLineHeight(5);
			$pdf->SetAligns(array('', ''));
			$pdf->SetFont('Arial', 'B', 12);
			$pdf->Cell(99, 5, 'Info Perusahaan', 0, 0);
			$pdf->Cell(90, 5, 'Tagihan Untuk', 0, 1); //end of line
			$pdf->Ln(3);
			$pdf->Line(10, 48, 199, 48);

			$pdf->SetFont('Arial', '', 12);
			$pdf->RowN(array($nm[0], $nm[1]));
			$pdf->RowN(array($al[0], $al[1]));
			$pdf->RowN(array($tp[0], 'Telp: ' . $tp[1]));
			$pdf->RowN(array($em[0], 'Email: ' . $em[1]));
			$pdf->Ln();
		}

		$pdf->SetWidths(array(65, 15, 25, 15, 25, 44));
		$pdf->SetLineHeight(5);
		$pdf->SetAligns(array('', 'R', 'R', 'R', 'C', 'R'));
		$pdf->SetFont('Arial', 'B', 12);
		$pdf->Cell(65, 5, 'Produk', 1, 0);
		$pdf->Cell(15, 5, 'Qty', 1, 0, 'C');
		$pdf->Cell(25, 5, 'Harga', 1, 0, 'C');
		$pdf->Cell(15, 5, 'Disc', 1, 0, 'C');
		$pdf->Cell(25, 5, 'Pajak', 1, 0, 'C');
		$pdf->Cell(44, 5, 'Jumlah', 1, 1, 'C'); //end of line

		$pdf->SetFont('Arial', '', 12);
		foreach ($dat2 as $v) {
			$pdf->Row(array(
				$v['nama_barang'] . ' - ' . $v['deskripsi'],
				$v['qty'],
				number_format($v['harga_d'], 2, ',', '.'),
				$v['diskon'] . ' %',
				$v['pajak_d'] . ' %',
				number_format($v['jumlah_d'], 2, ',', '.')
			));
		}
		$pdf->Ln();

		foreach ($data as $b) {
			//summary
			$pdf->Cell(94, 5, '', 0, 0);
			$pdf->Cell(25, 5, 'Subtotal', 0, 0, 'R');
			$pdf->Cell(70, 5, 'Rp ' . number_format($b['subtotal'], 2, ',', '.'), 0, 1, 'R'); //end of line

			$pdf->Cell(94, 5, '', 0, 0);
			$pdf->Cell(25, 5, 'Total Diskon', 0, 0, 'R');
			$pdf->Cell(70, 5, 'Rp ' . '(' . number_format($b['total_diskon'], 2, ',', '.') . ')', 0, 1, 'R'); //end of line

			$pdf->Cell(94, 5, '', 0, 0);
			$pdf->Cell(25, 5, 'Diskon Tambahan', 0, 0, 'R');
			$pdf->Cell(70, 5, 'Rp ' . number_format($b['diskon_tambah'] / 100 * $b['subtotal'], 2, ',', '.'), 0, 1, 'R'); //end of line

			$pdf->Cell(94, 5, '', 0, 0);
			$pdf->Cell(25, 5, 'Pajak', 0, 0, 'R');
			$pdf->Cell(70, 5, 'Rp ' . number_format($b['pajak'], 2, ',', '.'), 0, 1, 'R'); //end of line

			$pdf->Cell(94, 5, '', 0, 0);
			$pdf->Cell(25, 5, 'Total', 0, 0, 'R');
			$pdf->Cell(70, 5, 'Rp ' . number_format($b['total'], 2, ',', '.'), 0, 1, 'R'); //end of line

			$pdf->Cell(74, 5, '', 0, 0);
			$pdf->Cell(45, 7, 'Pajak Inclusive ' . $b['pajak_inc'] . '%', 'B', 0, 'R');
			$cc = ((100 / (100 + $b['pajak_inc'])) * $b['total']) * $b['pajak_inc'] / 100;
			$pdf->Cell(70, 7, 'Rp ' . number_format($cc, 2, ',', '.'), 'B', 1, 'R'); //end of line

			$pdf->Ln(2);
			$pdf->Cell(94, 5, '', 0, 0);
			$pdf->Cell(25, 5, 'Jumlah Tertagih:', 0, 0, 'R');
			$pdf->Cell(70, 5, 'Rp ' . number_format($b['jumlah_tagihan'], 2, ',', '.'), 0, 1, 'R'); //end of line
			$pdf->Ln(3);

			$ket = array(
				'Terima kasih atas kepercayaan anda',
				'Purchase order akan di terima jika sudah melalukan full payment',
				'Simpan bukti purchase order ini sebagai bukti yang SAH.',
				'Pembayaran di lakukan ke Account Rek BCA 4140474440 a/n HARYONO'
			);

			$pdf->SetFont('Arial', 'B', 12);
			$pdf->Cell(99, 10, 'Keterangan', 'B', 1);
			$pdf->Ln(2);
			$pdf->SetFont('Arial', '', 12);
			$pdf->Cell(99, 5, $ket[0], 0, 1);
			$pdf->Ln();

			$pdf->SetWidths(array(6, 93));
			$pdf->SetLineHeight(5);
			$pdf->SetAligns(array('', ''));
			$pdf->SetFont('Arial', 'B', 12);
			$pdf->Cell(99, 10, 'Syarat & Ketentuan', 'B', 1);
			$pdf->Ln(2);

			$pdf->SetFont('Arial', 'I', 12);
			$pdf->Cell(99, 5, 'Paymet Metode ;', 0, 1);
			$pdf->Ln(2);
			$pdf->RowN(array('1.', $ket[1]));
			$pdf->RowN(array('2.', $ket[2]));
			$pdf->RowN(array('3.', $ket[3]));
			$pdf->Ln();

			$pdf->SetFont('Arial', '', 12);
			$date = date_create($b['tanggal_']);
			$pdf->Cell(130, 5, '', 0, 0);
			$pdf->Cell(25, 5, date_format($date, "j M, Y"), 0, 1, 'C');
			$pdf->Ln(20);
			$pdf->Cell(130, 5, '', 0, 0);
			$pdf->Cell(25, 5, 'Finance', 0, 1, 'C'); //end of line
		}

		$file_name = $id;
		$pdf->Output('I', $file_name);
	}

	public function toggle($getId)
	{
		$id = encode_php_tags($getId);
		$status = $this->admin->get('brg_masuk', ['no_po' => $id])['status'];
		$toggle = $status ? 0 : 1; //Jika user aktif maka nonaktifkan, begitu pula sebaliknya
		$pesan = $toggle ? 'po confirmed.' : 'po on process.';

		if ($this->admin->update('brg_masuk', 'no_po', $id, ['status' => $toggle])) {
			set_pesan($pesan);
		}
		redirect('barangmasuk');
	}

	public function get_data($barangId)
	{
		$data = $this->admin->getBMDbarang(null, $barangId);
		header('Content-Type: application/json');
		echo json_encode($data);
	}

	public function lihat($id)
	{
		$data['barang'] = $this->admin->get('barang', null);
		$data['supplier'] = $this->admin->get('supplier', null);
		$data['barang_masuk'] = $this->admin->get('brg_masuk', ['no_po' => $id]);
		$data['data_detail'] = $this->admin->getBMD(null, $id);
		$cekspid = $this->admin->get('brg_masuk', ['no_po' => $id])['supplier_id'];
		$ceksp = $this->admin->get('supplier', null, ['id_supplier' => $cekspid]);
		$data['title'] =  $ceksp[0]['nama_supplier'] . '|' . $data['barang_masuk']['tanggal_bm'];
		$this->template->load('templates/dashboard', 'brg_masuk/lihat_bm', $data);
	}
}
