<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* Memcached Settings */
$config = array(
	'default' => array(
		'hostname' => '127.0.0.1',
		'port'     => '11211',
		'weight'   => '1',
	),
);
