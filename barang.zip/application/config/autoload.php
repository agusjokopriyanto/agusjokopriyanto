<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* Packages */
$autoload['packages'] = array();

/* Libraries */
$autoload['libraries'] = array('database', 'session', 'template');

/* Drivers */
$autoload['drivers'] = array();

/* Helper */
$autoload['helper'] = array('form', 'url', 'fungsi', 'security');

/* Config */
$autoload['config'] = array();

/* Language */
$autoload['language'] = array();

/* Models */
$autoload['model'] = array();
