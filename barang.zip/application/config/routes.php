<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* URI Routing */
// $route['default_controller']    = 'home';
$route['default_controller'] = 'auth';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['login'] = 'auth';
$route['logout'] = 'auth/logout';
$route['register'] = 'auth/register';
$route['transaksi'] = 'penjualan/add';
$route['transaksics'] = 'penjualan/addcs';
$route['customer'] = 'penjualan/cust';