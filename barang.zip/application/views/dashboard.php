<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
             <!--Card Header - Dropdown-->
            <div class="card-header bg-primary py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-white">Omset Penjualan Barang Perbulan pada Tahun <?= date('Y'); ?></h6>
            </div>
             <!--Card Body-->
            <div class="card-body">
                <div class="chart-area">
                    <div class="chartjs-size-monitor">
                        <div class="chartjs-size-monitor-expand">
                            <div class=""></div>
                        </div>
                        <div class="chartjs-size-monitor-shrink">
                            <div class=""></div>
                        </div>
                    </div>
                    
                    <canvas id="barChart" width="669" height="220"></canvas>
                    
                    <script>
                        var ctx = document.getElementById('barChart').getContext('2d');
                        var months = <?= json_encode(array_keys($barChart)); ?>;
                        var data = <?= json_encode(array_values($barChart)); ?>;
                        var flatColors = [
                            'rgb(128, 0, 128,0.9)',
                            'rgb(255, 99, 132,0.9)',
                            'rgb(54, 162, 235,0.9)',
                            'rgb(255, 206, 86,0.9)',
                            'rgb(75, 192, 192,0.9)',
                            'rgb(153, 102, 255,0.9)',
                            'rgb(255, 159, 64,0.9)',
                            'rgb(220, 20, 60,0.9)',
                            'rgb(0, 128, 0,0.9)',
                            'rgb(255, 0, 0,0.9)',
                            'rgb(0, 0, 255,0.9)',
                            'rgb(255, 165, 0,0.9)',
                        ];
                    
                        // Create separate datasets for each month
                        var datasets = months.map(function(month, index) {
                            return {
                                label: month,
                                data: [data[index]],
                                backgroundColor: [flatColors[index]], // Set color for each month
                                borderColor: [flatColors[index]], // Set color for each month
                                borderWidth: 1
                            };
                        });
                    
                        var barChart = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                labels: [''], // Empty labels to avoid displaying labels above bars
                                datasets: datasets
                            },
                            options: {
                                plugins: {
                                    datalabels: {
                                        anchor: 'end', // Position labels to the end (right side) of the bars
                                        align: 'top', // Align labels to the top of the bars
                                        color: 'black', // Label text color
                                        font: {
                                            size: 12 // Label font size
                                        },
                                        formatter: function(value, context) {
                                            return value.toLocaleString(); // Format label text as desired
                                        }
                                    }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        ticks: {
                                            callback: function(value, index, values) {
                                                return value.toLocaleString(); // Format y-axis labels as desired
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    </script>




                </div>
            </div>
        </div>
    </div>
</div>

<!-- <div class="row">

    <div class="col-xl-3 col-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Data Barang</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $barang; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-folder fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Data Supplier</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $supplier; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Stok Barang</div>
                                <div class="mb-0 font-weight-bold text-gray-800">
                                    <?= number_format($stok, 2, '.', ''); ?> Kardus Sotong<br>
                                    <?= number_format($stok*10, 2, '.', ''); ?> Kg Sotong<hr>
                                    <?= number_format($stok2, 2, '.', ''); ?> Kg Stok barang yang lain<br>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="progress progress-sm mr-2">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total User</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $user; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-plus fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->


  <!-- DI HIDE KARENA GAK KEPAKE DI DASBOART
<!--
    <!-- Area Chart
    <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown
            <div class="card-header bg-primary py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-white">Total Transaksi Barang Perbulan pada Tahun <?= date('Y'); ?></h6>
            </div>
            <!-- Card Body
            <div class="card-body">
                <div class="chart-area">
                    <div class="chartjs-size-monitor">
                        <div class="chartjs-size-monitor-expand">
                            <div class=""></div>
                        </div>
                        <div class="chartjs-size-monitor-shrink">
                            <div class=""></div>
                        </div>
                    </div>
                    <canvas id="myAreaChart" width="669" height="320" class="chartjs-render-monitor" style="display: block; width: 669px; height: 320px;"></canvas>
                </div>
            </div>
        </div>
    </div>
-->
    <!-- Pie Chart
    <div class="col-xl-4 col-lg-5">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown
            <div class="card-header bg-primary py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-white">Transaksi Barang</h6>
            </div>
            <!-- Card Body


    <!--        <div class="card-body">
                <div class="chart-pie pt-4 pb-2">
                    <div class="chartjs-size-monitor">
                        <div class="chartjs-size-monitor-expand">
                            <div class=""></div>
                        </div>
                        <div class="chartjs-size-monitor-shrink">
                            <div class=""></div>
                        </div>
                    </div>
                    <canvas id="myPieChart" width="302" height="245" class="chartjs-render-monitor" style="display: block; width: 302px; height: 245px;"></canvas>
                </div>
                <div class="mt-4 text-center small">
                    <span class="mr-2">
                        <i class="fas fa-circle text-primary"></i> Barang Masuk
                    </span>
                    <span class="mr-2">
                        <i class="fas fa-circle text-danger"></i> Barang Keluar
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>

-->




<div class="row">
    <!-- table jatuh tempo -->
    <!-- <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header bg-danger py-3">
                <h6 class="m-0 font-weight-bold text-white text-center">Jatuh Tempo</h6>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 table-sm table-striped text-center">
                    <thead>
                        <tr>
                            <th>Tanggal Inv</th>
                            <th>Tanggal Tempo</th>
                            <th>Nama</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($tempo) :
                            foreach ($tempo as $tp) :
                                $nama = explode(':',$tp['data']);
                                ?>
                                <tr>
                                    <td><?= $tp['tanggal_']; ?></td>
                                    <td><?= $tp['tanggal_tempo']; ?></td>
                                    <td><?= $nama[0]; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="3" class="text-center">
                                    Tidak ada data jatuh tempo
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> -->

    <!-- table stok minimum-->
    <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header bg-danger py-3">
                <h6 class="m-0 font-weight-bold text-white text-center">Stok Barang Minimum</h6>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 text-center table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Barang</th>
                            <th>Stok</th>
                            <!-- <th>Pasok</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($brg_min) :
                            foreach ($brg_min as $b) :
                                ?>
                                <tr>
                                    <td align="left"><?= $b['nama_barang']; ?></td>
                                    <td style="width: 100px;"><?= $b['stok'] ." ". $b['nama_satuan']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="3" class="text-center">
                                    Tidak ada barang stok minim
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

	<!-- table stok maximum-->
    <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header bg-warning py-3">
                <h6 class="m-0 font-weight-bold text-white text-center">Stok Barang Maximum</h6>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 text-center table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Barang</th>
                            <th>Stok</th>
                            <!-- <th>Pasok</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($brg_max) :
                            foreach ($brg_max as $b) :
                                ?>
                                <tr>
                                    <td align="left"><?= $b['nama_barang']; ?></td>
                                    <td style="width: 100px;"><?= $b['stok'] ." ". $b['nama_satuan']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="3" class="text-center">
                                    Tidak ada barang stok minim
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!--table barang masuk-->
    <!-- <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header bg-success py-3">
                <h6 class="m-0 font-weight-bold text-white text-center">Transaksi Barang Masuk</h6>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 table-sm table-striped text-center">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Barang</th>
                            <th>Ukuran</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transaksi['barang_masuk'] as $tbm) :
                            $uk = explode(':', $tbm['ukuran']); ?>
                            <tr>
                                <td><strong><?= $tbm['tanggal_masuk']; ?></strong></td>
                                <td align="left"><?= $tbm['nama_barang']; ?></td>
                                <td><?= $uk[0] ."m x ".$uk[1] ."m | ".$uk[2]." kg" ?></td>
                                <td><?= $uk[0] ."m x ".$uk[1] ."m" ?></td>
                                <td><span class="badge badge-success"><?= $tbm['jumlah_masuk']." ". $tbm['nama_satuan']; ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> -->

    <!--table barang keluar-->
    <!-- <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header bg-danger py-3">
                <h6 class="m-0 font-weight-bold text-white text-center">Transaksi Barang Keluar</h6>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 table-sm table-striped text-center">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Barang</th>
                            <th>Ukuran</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($transaksi['barang_keluar']) :
                            foreach ($transaksi['barang_keluar'] as $tbk) :
                            $uk = explode(':', $tbk['ukuran']); ?>
                            <tr>
                                <td><strong><?= $tbk['tanggal_keluar']; ?></strong></td>
                                <td align="left"><?= $tbk['nama_barang']; ?></td>
                                <td><?= $uk[0] ."m x ".$uk[1] ."m" ?></td>
                                <td><span class="badge badge-danger">
                                    <?php
                                        echo $tbk['jumlah_keluar']." ". $tbk['nama_satuan'];
                                     ?>
                                </span></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="3" class="text-center">
                                    Tidak ada data transaksi barang keluar
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> -->

</div>

<!-- <div class="row">
    <div class="col-md-4">
        <div class="card shadow mb-4">
            <div class="card-header bg-primary py-3">
                <h6 class="m-0 font-weight-bold text-white text-center">Transaksi Barang West</h6>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 table-sm table-striped text-center">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Barang</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transaksi['barang_west'] as $tbk) : ?>
                            <tr>
                                <td><strong><?= $tbk['tanggal_west']; ?></strong></td>
                                <td align="left"><?= $tbk['nama_barang']; ?></td>
                                <td><span class="badge badge-primary">
                                    <?php
                                        echo $tbk['jumlah_west']." ". $tbk['nama_satuan'];
                                     ?>
                                </span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div> -->