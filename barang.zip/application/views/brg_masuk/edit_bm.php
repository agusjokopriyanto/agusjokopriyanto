<div class="row justify-content-center">
	<div class="col-md-10">
		<div class="card shadow-sm border-bottom-primary">
			<div class="card-header bg-white py-3">
				<div class="row">
					<div class="col">
						<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
							Form Edit Barang Masuk
						</h4>
					</div>
					<div class="col-auto">
						<a href="<?= base_url('barangmasuk') ?>" class="btn btn-sm btn-secondary btn-icon-split">
							<span class="icon">
								<i class="fa fa-arrow-left"></i>
							</span>
							<span class="text">
								Kembali
							</span>
						</a>
					</div>
				</div>
			</div>
			<div class="card-body">
				<!-- isi dari top barangmasuk -->
				<?= $this->session->flashdata('pesan'); ?>

				<?= form_open('barangmasuk/proses_t', [], ['no_po' => $barang_masuk['no_po']]); ?>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="tanggal_bm">Tanggal Barang Masuk</label>
					<div class="col-md-4">
						<input value="<?= set_value('tanggal_bm', date('Y-m-d')); ?>" name="tanggal_bm" id="tanggal_bm" type="text" class="form-control date" placeholder="Tanggal Masuk...">
						<?= form_error('tanggal_bm', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="supplier_id">Supplier</label>
					<div class="col-md-4">
						<select name="supplier_id" id="supplier_id" class="custom-select select2" disabled>
							<option value="" selected disabled>Pilih Supplier</option>
							<?php foreach ($supplier as $b) : ?>
								<option <?= $barang_masuk['supplier_id'] == $b['id_supplier'] ? 'selected' : ''; ?> <?= set_select('supplier_id', $b['id_supplier']) ?> value="<?= $b['id_supplier'] ?>"><?= $b['nama_supplier'] ?></option>
							<?php endforeach; ?>
						</select>
						<?= form_error('supplier_id', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-md-1">
					</div>
					<div class="col-md-11">
						<div class="table-responsive">
							<table class="table table-striped w-100 dt-responsive nowrap">
								<thead>
									<tr>
										<th>No. </th>
										<th>SKU</th>
										<th>Nama Barang</th>
										<th>Qty</th>
										<th>Harga</th>
										<th>Grade</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$no = 1;
									if ($data_detail) :
										foreach ($data_detail as $bm) :
									?>
											<tr>
												<td><?= $no++; ?></td>
												<td><?= $bm['barang_id'] ?></td>
												<td><?= $bm['nama_barang'] ?></td>
												<td><?= $bm['qty']; ?></td>
												<td><?= number_format($bm['harga'],0,',','.'); ?></td>
												<td><?= $bm['grade']; ?></td>
												<td>
													<a onclick="openEditModal('<?= $bm['barang_id'] ?>')" class="btn btn-warning btn-circle btn-sm"><i class="fa fa-edit"></i></a>
													<a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('barangmasuk/del_d/') . $bm['barang_id'].'/'.$bm['d_po'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
												</td>
											</tr>
										<?php endforeach; ?>
									<?php else : ?>
										<tr>
											<td colspan="7" class="text-center">
												Data Kosong
											</td>
										</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="row form-group">
					<div class="col offset-md-2">
						<button type="submit" class="btn btn-primary">Simpan</button>
						<button type="reset" class="btn btn-secondary">Reset</button>
					</div>
				</div>
				<?= form_close(); ?>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade bd-example-modal-lg" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Edit Detail Barang</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<?= form_open('barangmasuk/proses_d', [], ['d_po' => $barang_masuk['no_po']]); ?>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="barang_id">Produk</label>
					<div class="col-md-6">
					<input id="barang_nid" type="text" class="form-control" readonly>
					<input name="barang_id" id="barang_id" type="hidden" class="form-control" readonly>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="qty">Quantity</label>
					<div class="col-md-6">
						<input name="qty" id="qty" type="number" class="form-control" placeholder="Quantity...">
						<?= form_error('qty', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="harganet">Harga Net</label>
					<div class="col-md-6">
						<input name="harganet" id="harganet" type="number" class="form-control" placeholder="Harga Net...">
						<?= form_error('harganet', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="price">Price %</label>
					<div class="col-md-3">
					    <div class="input-group">
					        <input name="price" id="price" type="number" class="form-control" placeholder="xx%">
					        <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">%</span>
                              </div>
					    </div>
						<!--<select name="price" id="price" class="form-control">-->
						<!--	<option value="" disabled>Pilih Price</option>-->
						<!--	<option value="0">0%</option>-->
						<!--	<option value="10">10%</option>-->
						<!--	<option value="20">20%</option>-->
						<!--	<option value="30">30%</option>-->
						<!--	<option value="40">40%</option>-->
						<!--	<option value="50">50%</option>-->
						<!--	<option value="60">60%</option>-->
						<!--</select>-->
						<?= form_error('price', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="harga">Harga</label>
					<div class="col-md-6">
						<input name="harga" id="harga_akhir" type="number" class="form-control" placeholder="Harga..." readonly>
						<?= form_error('harga', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="grade">Grade</label>
					<div class="col-md-6">
						<select name="grade" id="grade" class="custom-select">
							<option value="">Pilih Grade </option>
							<option value="A">A</option>
							<option value="B">B</option>
							<option value="C">C</option>
						</select>
						<?= form_error('grade', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="kd_lokasi">Kode Lokasi</label>
					<div class="col-md-6">
						<input name="kd_lokasi" id="kd_lokasi_akhir" type="text" class="form-control" placeholder="kode lokasi...">
						<?= form_error('kd_lokasi', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<div class="col offset-md-4">
						<button type="submit" class="btn btn-primary">Update</button>
						<button type="reset" class="btn btn-secondary">Reset</button>
					</div>
				</div>
				<?= form_close(); ?>
			</div>
		</div>
	</div>
	<!-- </div> -->
