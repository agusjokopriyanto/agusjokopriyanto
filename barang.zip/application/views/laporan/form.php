<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    Form Laporan
                </h4>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open('', array('id' => 'form1')); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="transaksi">Laporan Transaksi</label>
                    <div class="col-md-9">
                        <div class="custom-control custom-radio">
                            <input value="brg_masuk" type="radio" id="brg_masuk" name="transaksi" class="custom-control-input">
                            <label class="custom-control-label" for="brg_masuk">Barang Masuk</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input value="penjualan" type="radio" id="penjualan" name="transaksi" class="custom-control-input">
                            <label class="custom-control-label" for="penjualan">Penjualan</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input value="barang_broken" type="radio" id="barang_broken" name="transaksi" class="custom-control-input">
                            <label class="custom-control-label" for="barang_broken">Barang Broken</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input value="sales" type="radio" id="sales" name="transaksi" class="custom-control-input">
                            <label class="custom-control-label" for="sales">Sales</label>
                        </div>
						<div class="custom-control custom-radio">
                            <input value="retur" type="radio" id="retur" name="transaksi" class="custom-control-input">
                            <label class="custom-control-label" for="retur">Barang Retur</label>
                        </div>
						<!--<div class="custom-control custom-radio">-->
      <!--                      <input value="barang_cancel" type="radio" id="barang_cancel" name="transaksi" class="custom-control-input">-->
      <!--                      <label class="custom-control-label" for="barang_cancel">Barang Cancel</label>-->
      <!--                  </div>-->
                        <?= form_error('transaksi', '<span class="text-danger small">', '</span>'); ?>
                    </div>
                </div>
                <div class="row from-group">
                    <label class="col-md-3 text-md-right" for="transaksi">Sales</label>
                    <div class="col-md-3">
						<select name="sales_id" id="sales_id" class="select2">
							<option value="" selected disabled>Pilih Sales</option>
							<?php foreach ($sales as $b) : ?>
								<option value="<?= $b['id_sales'] ?>"><?= $b['nama_sales'] ?></option>
							<?php endforeach; ?>
						</select>
						<?= form_error('sales_id', '<small class="text-danger">', '</small>'); ?>
					</div>
                </div>
                <div class="row form-group">
                    <label class="col-lg-3 text-lg-right" for="tanggal">Tanggal</label>
                    <div class="col-lg-5">
                        <div class="input-group">
                            <input  name="tanggal" id="tanggal" type="text" class="form-control" placeholder="Periode Tanggal">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-fw fa-calendar"></i></span>
                            </div>
                        </div>
                        <?= form_error('tanggal', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-lg-9 offset-lg-3">
                        <button type="submit" class="btn btn-primary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-print"></i>
                            </span>
                            <span class="text">
                                Cetak
                            </span>
                        </button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>
