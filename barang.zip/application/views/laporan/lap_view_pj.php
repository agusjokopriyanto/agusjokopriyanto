<!DOCTYPE html>
<html>

<head>
	<title><?= $title; ?></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			background-color: grey;
		}

		.container {
			height: 100%; 
			max-width: 297mm;
			/*min-height: 210mm;*/
			margin: 0 auto;
			padding:  20px 5px;
			background-color: white;
		}

		.footer {
			text-align: right;
			margin-top: 20px;
			font-size: 14px;
		}

		td {
			padding: 5px;
		}

		th {
			padding: 5px;
		}
	</style>
</head>

<body>
	<div class="container">
		<h2 style="text-align: center;"><?= $title ?></h2>
		<p style="text-align: center;">Periode <?= $range ?></p>

		<table class="isi" style="border-collapse: collapse; width: 100%;" border="1">
			<thead>
				<tr>
					<th style="text-align: left;">Inv</th>
					<th>Tanggal</th>
					<th>Nama Barang</th>
					<th>Harga</th>
					<th>Qty</th>
					<th>Sales</th>
					<th>Subtotal</th>
					<th>Kasir</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($data_header as $h) :
					$query = $this->db
						->select('*')
						->from('penjualan_d')
						->join('barang', 'barang.id_barang = penjualan_d.barang_id', 'left')
						->where('d_pj', $h['no_notap'])
						->get()
						->result_array();
				?>
					<tr style="vertical-align: top;">
						<td><?= $h['no_notap'] ?></td>
						<td><?= $h['tanggal_'] ?></td>
						<td><?php foreach ($query as $row) echo '- '.$row['nama_barang'] . '<br>'; ?></td>
						<td style="text-align: right;"><?php foreach ($query as $row) echo formatCurrency($row['harga']) . '<br>'; ?></td>
						<td style="text-align: center;"><?php foreach ($query as $row) echo $row['qty'] . '<br>'; ?></td>
						<td><?= $h['nama_sales']; ?></td>
						<td style="text-align: right;"><?=formatCurrency($h['subtotal']) . '<br>'; ?></td>
						<td rowspan="2"><?= $h['nama'] ?></td>
					</tr>
					<tr>
						<td colspan="6" style="text-align: right;">
							Harga Nego <br>
							Voucher <br>
							Grand Total
						</td>
						<th style="text-align: right;">
							<?= formatCurrency($h['nego']) ?> <br>
							<?= formatCurrency($h['nominal']) ?> <br>
							<?= formatCurrency($h['grandtotal']) ?>
						</th>
					</tr>
				<?php
				endforeach; ?>
			</tbody>
		</table>
	</div>

	<script>
		window.onload = function() {
			// This function will be called when the page has fully loaded
			window.print(); // Trigger the print dialog
		};
	</script>
</body>

</html>
<?php
function formatCurrency($number)
{
	$fmt = new NumberFormatter('id-ID', NumberFormatter::DECIMAL);
	return $fmt->format($number);
}
?>
