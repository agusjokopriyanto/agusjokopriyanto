<!DOCTYPE html>
<html>

<head>
	<title><?= $title; ?></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			background-color: grey;
		}

		.container {
			 height: 100%; 
			max-width: 297mm;
			/*min-height: 210mm;*/
			margin: 0 auto;
			padding: 20px 5px;
			background-color: white;
		}

		.footer {
			text-align: right;
			margin-top: 20px;
			font-size: 14px;
		}

		td {
			padding: 5px;
		}

		th {
			padding: 5px;
		}
	</style>
</head>

<body>
	<div class="container">
		<h2 style="text-align: center;"><?= $title ?> <?= $data_header[0]['nama_sales'] ?></h2>
		<p style="text-align: center;">Periode <?= $range ?></p>

		<table class="isi" style="border-collapse: collapse; width: 100%;" border="1">
			<thead>
				<tr>
					<th>Tanggal</th>
					<th>Inv</th>
					<th>Penjualan</th>
				</tr>
			</thead>
			<tbody>
                <?php
                $grandTotal = 0; // Initialize the grand total variable outside the loop
            
                foreach ($data_header as $h) :
                    $query = $this->db
                        ->select('*')
                        ->from('penjualan')
                        ->join('sales', 'sales.id_sales = penjualan.sales_id', 'left')
                        ->where('sales_id', $data_header[0]['id_sales'])
                        ->where('selesai', '1')
                        ->where('tanggal_ >=', $awal)
                        ->where('tanggal_ <=', $akhir)
                        ->order_by('penjualan.tanggal_', 'ASC')
                        ->get()
                        ->result_array();
                    $subtotal = 0; // Initialize the subtotal variable for each group
                    foreach ($query as $row) {
                    ?>
                    <tr style="vertical-align: top;">
                        <td><?= $row['tanggal_']; ?></td>
                        <td><?= $row['no_notap']; ?></td>
                        <td style="text-align: right;">
                            <?php 
                                $itemTotal = $row['grandtotal'];
                                echo formatCurrency($itemTotal);
                                $subtotal += $itemTotal;
                            ?>
                        </td>
                    </tr>
                    <?php }
                    $grandTotal += $subtotal; // Add the subtotal for the group to the grand total
                endforeach;
                ?>
            
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="2" style="text-align: right;">Sub Total:</th>
                    <th style="text-align: right;"><?= formatCurrency($grandTotal) ?></th>
                </tr>
            </tfoot>

		</table>
	</div>

	<script>
		window.onload = function() {
			// This function will be called when the page has fully loaded
			window.print(); // Trigger the print dialog
		};
	</script>
</body>

</html>
<?php
function formatCurrency($number)
{
	$fmt = new NumberFormatter('id-ID', NumberFormatter::DECIMAL);
	return $fmt->format($number);
}
?>
