<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
    <div class="card-header bg-white py-3">
        <div class="row">
            <div class="col">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    Data Surat Jalan
                </h4>
            </div>
            <div class="col-auto">
                <a href="<?= base_url('suratjalan/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
                    <span class="icon">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">
                        Tambah Surat Jalan
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped" id="dataTable1">
            <thead>
                <tr>
                    <th>No. </th>
                    <th>Nomor Surat</th>
                    <th>Tanggal</th>
                    <th>Nama Pelanggan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if ($data_sj) :
                    foreach ($data_sj as $sj) :
                        $nn = explode('-',$sj['no_suratjalan']);
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $nn[0].'/'.$nn[1].'/'.$nn[2]; ?></td>
                            <td><?= $sj['tgl_suratjalan']; ?></td>
                            <td><?= $sj['nama']; ?></td>
                            <td>
                                <!-- <a href="<?= base_url('suratjalan/edit/') . $sj['id'] ?>" class="btn btn-warning btn-circle btn-sm"><i class="fa fa-edit"></i></a> -->
                                <a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('suratjalan/delete/') . $sj['no_suratjalan'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                                <a href="<?= base_url('suratjalan/print_/') . $sj['no_suratjalan'] ?>" target="_blank" class="btn btn-sm btn-info btn-circle"><i class="fa fa-file-pdf"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="5" class="text-center">
                            Data Kosong
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>