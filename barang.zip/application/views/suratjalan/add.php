<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Tambah Surat Jalan
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('suratjalan') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Kembali
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open('suratjalan/proses_t', []); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="no_suratjalan">Nomor</label>
                    <div class="col-md-4">
                        <input value="<?= set_value('no_suratjalan', $no_sj); ?>" name="no_suratjalan" id="no_suratjalan" type="text" class="form-control" placeholder="Nomor Surat Jalan..." readonly>
                        <?= form_error('no_suratjalan', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="tgl_suratjalan">Tanggal</label>
                    <div class="col-md-4">
                        <input value="<?= set_value('tgl_suratjalan', date('Y-m-d')); ?>" name="tgl_suratjalan" type="text" class="form-control date" placeholder="Tanggal Surat Jalan...">
                        <?= form_error('tgl_suratjalan', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="nama">Nama</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('nama'); ?>" name="nama" id="nama" type="text" class="form-control" placeholder="Nama Pelanggan...">
                        <?= form_error('nama', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="alamat">Alamat</label>
                    <div class="col-md-9">
                        <textarea name="alamat" id="alamat" class="form-control" rows="2" placeholder="Alamat..."><?= set_value('alamat'); ?></textarea>
                        <?= form_error('alamat', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-md-2">
                    </div>
                    <div class="col-md-10">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal"> 
                            <span class="icon">
                                <i class="fa fa-plus"></i>
                            </span>
                            <span class="text">
                                Add Detail
                            </span>
                        </button>
                    <div class="">
                        <table class="table table-striped table-responsive-lg">
                            <thead>
                                <tr>
                                    <th>No. </th>
                                    <th>Nama Barang</th>
                                    <th>Jumlah</th>
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                if ($data_detail) :
                                    foreach ($data_detail as $bm) :
                                        ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= $bm['nama_barang'] ?></td>
                                            <td><?= $bm['jumlah']; ?></td>
                                            <td><?= $bm['keterangan']; ?></td>
                                            <td>
                                                <a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('suratjalan/del_d/').$no_sj ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="8" class="text-center">
                                            Data Kosong
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>
            <div class="row form-group">
                <div class="col-md-9 offset-md-3">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
            <?= form_close(); ?>
        </div>
    </div>
</div>
</div>

<!-- modal tambah detail -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Detail Surat Jalan</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
    </div>

    <!-- Modal body -->
    <div class="modal-body">
        <?= form_open('suratjalan/proses_d', []); ?>
        <div class="row form-group">
            <label class="col-md-3 text-md-right" for="nm_barang">Produk</label>
            <div class="col-md-6">
                <input readonly value="<?= set_value('no_suratjalan', $no_sj); ?>" name="no_suratjalan" id="no_suratjalan" type="hidden" class="form-control" placeholder="No suratjalan">
                <select name="nm_barang" id="nm_barang" class="custom-select">
                    <option value="" selected disabled>Pilih Barang</option>
                    <?php foreach ($barang as $b) : ?>
                        <option <?= $this->uri->segment(3) == $b['id_barang'] ? 'selected' : '';  ?> <?= set_select('barang_id', $b['id_barang']) ?> value="<?= $b['id_barang'] ?>"><?= $b['id_barang'] . ' | ' . $b['nama_barang'] ?></option>
                    <?php endforeach; ?>
                </select>
                <?= form_error('idbarang', '<small class="text-danger">', '</small>'); ?>
            </div>
        </div>
        <div class="row form-group">
            <label class="col-md-3 text-md-right" for="jumlah">Jumlah</label>
            <div class="col-md-6">
                <input name="jumlah" id="jumlah" type="number" class="form-control" placeholder="Jumlah...">
                <?= form_error('jumlah', '<small class="text-danger">', '</small>'); ?>
            </div>
        </div>
        <div class="row form-group">
            <label class="col-md-3 text-md-right" for="keterangan">Keterangan</label>
            <div class="col-md-6">
                <div class="input-group">
                    <textarea name="keterangan" id="keterangan" class="form-control" rows="2" placeholder="Keterangan..."><?= set_value('keterangan'); ?></textarea>
                </div>
                <?= form_error('keterangan', '<small class="text-danger">', '</small>'); ?>
            </div>
        </div>
        <div class="row form-group">
            <div class="col offset-md-2">
                <button type="submit" class="btn btn-primary">Add</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
        </div>
        <?= form_close(); ?>
    </div>
</div>
</div>
</div>
