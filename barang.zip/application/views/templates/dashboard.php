<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title><?= $title; ?> | GUDANG TOFIX</title>

	<!-- Custom fonts for this template-->
	<link href="<?= base_url(); ?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="<?= base_url(); ?>assets/css/fonts.min.css" rel="stylesheet">

	<!-- Custom styles for this template-->
	<link href="<?= base_url(); ?>assets/css/sb-admin-2.min.css" rel="stylesheet">

	<!-- Datepicker -->
	<link href="<?= base_url(); ?>assets/vendor/daterangepicker/daterangepicker.css" rel="stylesheet">

	<!-- DataTables -->
	<link href="<?= base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
	<link href="<?= base_url(); ?>assets/vendor/datatables/buttons/css/buttons.bootstrap4.min.css" rel="stylesheet">
	<link href="<?= base_url(); ?>assets/vendor/datatables/responsive/css/responsive.bootstrap4.min.css" rel="stylesheet">
	<link href="<?= base_url(); ?>assets/vendor/gijgo/css/gijgo.min.css" rel="stylesheet">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css">

	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

	<style>
		#accordionSidebar,
		.topbar {
			z-index: 1;
		}
		
		.custom-select22 {
            width: 200px;
        }
	</style>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


</head>

<body id="page-top">

	<!-- Page Wrapper -->
	<div id="wrapper">

		<!-- Sidebar -->
		<ul class="navbar-nav bg-white sidebar sidebar-light accordion shadow-sm" id="accordionSidebar">

			<!-- Sidebar - Brand -->
			<a class="sidebar-brand d-flex text-white align-items-center bg-primary justify-content-center" href="">
				<div class="sidebar-brand-icon">
					<!--<i class="fas fa-university"></i>-->
					<img class="img" src="<?= base_url() ?>assets/img/logo.JPG" style="width: 80px">
				</div>
				<div class="sidebar-brand-text mx-3">DNA</div>
			</a>

			<!-- Nav Item - Dashboard -->
			<li class="nav-item">
				<a class="nav-link" href="<?= base_url('dashboard'); ?>">
					<i class="fas fa-fw fa-tachometer-alt"></i>
					<span>Dashboard</span>
				</a>
			</li>
			

			<?php if (is_admin() || is_owner()) : ?>
    			<!-- Divider -->
    			<hr class="sidebar-divider">
			
				<!-- Heading -->
				<div class="sidebar-heading">
					Supervisor
				</div>

				<!-- Nav Item - Dashboard -->
				<li class="nav-item">
					<a class="nav-link " href="<?= base_url('approval'); ?>">
						<i class="fas fa-fw fa-list"></i>
						<span>Approval</span>
					</a>
				</li>

				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					Data Master
				</div>

				<!-- Nav Item - Dashboard -->
				<li class="nav-item">
					<a class="nav-link pb-0" href="<?= base_url('supplier'); ?>">
						<i class="fas fa-fw fa-users"></i>
						<span>Supplier</span>
					</a>
				</li>

				<!-- Nav Item - Pages Collapse Menu -->
				<li class="nav-item">
					<a class="nav-link collapsed pb-0" href="#" data-toggle="collapse" data-target="#collapseMaster" aria-expanded="true" aria-controls="collapseMaster">
						<i class="fas fa-fw fa-folder"></i>
						<span>Barang</span>
					</a>
					<div id="collapseMaster" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
						<div class="bg-light py-2 collapse-inner rounded">
							<h6 class="collapse-header">Master Barang:</h6>
							<a class="collapse-item" href="<?= base_url('satuan'); ?>">Satuan Barang</a>
							<a class="collapse-item" href="<?= base_url('kategori'); ?>">Kategori Barang</a>
							<a class="collapse-item" href="<?= base_url('barang'); ?>">Data Barang</a>
						</div>
					</div>
				</li>
				<!-- nav item sales -->
				<li class="nav-item">
					<a class="nav-link pb-0" href="<?= base_url('sales'); ?>">
						<i class="fas fa-users"></i>
						<span>Sales</span>
					</a>
				</li>
				<!-- Nav Item - voucher -->
				<li class="nav-item">
					<a class="nav-link" href="<?= base_url('voucher'); ?>">
						<i class="fas fa-money-bill"></i>
						<span>Voucher</span>
					</a>
				</li>

			<?php endif ?>

			<?php if (is_admin() || is_gudang()) : ?>

				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					DOCUMENT
				</div>

				<!-- Nav Item - Dashboard -->

				<!-- Nav Item - Dashboard -->
				<!-- <li class="nav-item">
					<a class="nav-link pb-0" href="<?= base_url('invoice'); ?>">
						<i class="fas fa-file-invoice"></i>
						<span>Invoice</span>
					</a>
				</li> -->
				<li class="nav-item">
					<a class="nav-link " href="<?= base_url('purchaseorder'); ?>">
						<i class="fas fa-money-bill"></i>
						<span>Purchase Order</span>
					</a>
				</li>
				<!-- <li class="nav-item">
					<a class="nav-link pb-0" href="<?= base_url('suratjalan'); ?>">
						<i class="fas fa-truck"></i>
						<span>Surat Jalan</span>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?= base_url('tandaterima'); ?>">
						<i class="fas fa-receipt"></i>
						<span>Tanda Terima</span>
					</a>
				</li> -->
				<!-- <li class="nav-item">
					<a class="nav-link " href="<?= base_url('pembukuan'); ?>">
						<i class="fas fa-book"></i>
						<span>Pembukuan</span>
					</a>
				</li> -->
			<?php endif ?>

			<?php if (is_admin() || is_gudang()) : ?>

				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					Transaksi
				</div>
            
				<!-- Nav Item - Dashboard -->
			
				<li class="nav-item">
					<a class="nav-link pb-0" href="<?= base_url('barang/opnime'); ?>">
						<i class="fas fa-fw fa-paper-plane"></i>
						<span>Stok Opnime</span>
					</a>
				</li>
			
			
				<li class="nav-item">
					<a class="nav-link pb-0" href="<?= base_url('barangmasuk'); ?>">
						<i class="fas fa-fw fa-download"></i>
						<span>Barang Masuk</span>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?= base_url('barangbroken'); ?>">
						<i class="fas fa-fw fa-file"></i>
						<span>Barang Broken</span>
					</a>
				</li>
				
			<?php endif ?>
			
			<?php if (is_admin() || is_kasir()) : ?>

				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					Transaksi Kasir
				</div>
				<li class="nav-item">
					<a class="nav-link pb-0" href="<?= base_url('penjualan'); ?>">
						<i class="fas fa-fw fa-shopping-cart"></i>
						<span>Riwayat Penjualan</span>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="<?= base_url('transaksi'); ?>">
						<i class="fas fa-fw fa-cart-plus"></i>
						<span>Kasir</span>
					</a>
				</li>
				<!--<li class="nav-item">-->
				<!--	<a class="nav-link" href="<?= base_url('settlement'); ?>">-->
				<!--		<i class="fas fa-fw fa-file"></i>-->
				<!--		<span>Settlement</span>-->
				<!--	</a>-->
				<!--</li>-->
				
				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					Transaksi Customer
				</div>
				<li class="nav-item">
					<a class="nav-link pb-0" href="<?= base_url('customer'); ?>">
						<i class="fas fa-fw fa-wallet"></i>
						<span>Customer DP</span>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="<?= base_url('transaksics'); ?>">
						<i class="fas fa-fw fa-cart-plus"></i>
						<span>Kasir CS</span>
					</a>
				</li>
			<?php endif ?>

			<?php if (is_admin()) : ?>

				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					Report
				</div>

				<li class="nav-item">
					<a class="nav-link" href="<?= base_url('laporan'); ?>">
						<i class="fas fa-fw fa-print"></i>
						<span>Cetak Laporan</span>
					</a>
				</li>


				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					Settings
				</div>

				<!-- Nav Item -->
				<li class="nav-item">
					<a class="nav-link" href="<?= base_url('user'); ?>">
						<i class="fas fa-fw fa-user-plus"></i>
						<span>User Management</span>
					</a>
				</li>
			<?php endif ?>

			<!-- Divider -->
			<hr class="sidebar-divider d-none d-md-block">

			<!-- Sidebar Toggler (Sidebar) -->
			<div class="text-center d-none d-md-inline">
				<button class="rounded-circle border-0" id="sidebarToggle"></button>
			</div>

		</ul>
		<!-- End of Sidebar -->

		<!-- Content Wrapper -->
		<div id="content-wrapper" class="d-flex flex-column">

			<!-- Main Content -->
			<div id="content">

				<!-- Topbar -->
				<nav class="navbar navbar-expand navbar-dark bg-primary topbar mb-4 static-top shadow-sm">

					<!-- Sidebar Toggle (Topbar) -->
					<button id="sidebarToggleTop" class="btn btn-link bg-transparent d-md-none rounded-circle mr-3">
						<i class="fa fa-bars text-white"></i>
					</button>

					<!-- Topbar Navbar -->
					<ul class="navbar-nav ml-auto">

						<!-- Nav Item - User Information -->
						<li class="nav-item dropdown no-arrow">
							<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<span class="mr-2 d-none d-lg-inline small text-capitalize">
									<?= userdata('nama'); ?>
								</span>
								<img class="img-profile rounded-circle" src="<?= base_url() ?>assets/img/avatar/<?= userdata('foto'); ?>">
							</a>
							<!-- Dropdown - User Information -->
							<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
								<a class="dropdown-item" href="<?= base_url('profile'); ?>">
									<i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
									Profile
								</a>
								<a class="dropdown-item" href="<?= base_url('profile/setting'); ?>">
									<i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
									Settings
								</a>
								<a class="dropdown-item" href="<?= base_url('profile/ubahpassword'); ?>">
									<i class="fas fa-lock fa-sm fa-fw mr-2 text-gray-400"></i>
									Change Password
								</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
									<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
									Logout
								</a>
							</div>
						</li>

					</ul>

				</nav>
				<!-- End of Topbar -->

				<!-- Begin Page Content -->
				<div class="container-fluid">

					<!-- Page Heading -->
					<h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

					<?= $contents; ?>

				</div>
				<!-- /.container-fluid -->

			</div>
			<!-- End of Main Content -->

			<!-- Footer -->
			<footer class="sticky-footer bg-light">
				<div class="container my-auto">
					<div class="copyright text-center my-auto">
						<span>Copyright &copy; Aplikasi Stok Barang GUDANG TOFIX <?php if (date('Y') > 2023) {
																						echo '2023 - ' . date('Y');
																					} else {
																						echo '2023';
																					} ?> &bull;
							<!-- by <?= anchor('https://www.agusjokopriyanto.id', 'agusjokopriyanto.id'); ?> -->
						</span>
					</div>
				</div>
			</footer>
			<!-- End of Footer -->

		</div>
		<!-- End of Content Wrapper -->

	</div>
	<!-- End of Page Wrapper -->

	<!-- Scroll to Top Button-->
	<a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	</a>

	<!-- Logout Modal-->
	<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Yakin ingin logout?</h5>
					<button class="close" type="button" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">Klik "Logout" dibawah ini jika anda yakin ingin logout.</div>
				<div class="modal-footer">
					<button class="btn btn-secondary" type="button" data-dismiss="modal">Batalkan</button>
					<a class="btn btn-primary" href="<?= base_url('logout'); ?>">Logout</a>
				</div>
			</div>
		</div>
	</div>

	<!-- Bootstrap core JavaScript-->
	<script src="<?= base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	<!-- Core plugin JavaScript-->
	<script src="<?= base_url(); ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>

	<!-- Custom scripts for all pages-->
	<script src="<?= base_url(); ?>assets/js/sb-admin-2.min.js"></script>

	<!-- Datepicker -->
	<script src="<?= base_url(); ?>assets/vendor/daterangepicker/moment.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/daterangepicker/daterangepicker.min.js"></script>

	<!-- Page level plugins -->
	<script src="<?= base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/buttons/js/dataTables.buttons.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/buttons/js/buttons.bootstrap4.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/jszip/jszip.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/pdfmake/pdfmake.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/pdfmake/vfs_fonts.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/buttons/js/buttons.html5.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/buttons/js/buttons.print.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/buttons/js/buttons.colVis.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/responsive/js/dataTables.responsive.min.js"></script>
	<script src="<?= base_url(); ?>assets/vendor/datatables/responsive/js/responsive.bootstrap4.min.js"></script>

	<script src="<?= base_url(); ?>assets/vendor/gijgo/js/gijgo.min.js"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
	<!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script> -->
	<!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script> -->
	<!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script> -->

    
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var salesRadio = document.getElementById("sales");
            var salesDropdown = document.getElementById("sales_id");
    
            // Initially, check if the "sales" radio button is selected on page load
            if (salesRadio.checked) {
                salesDropdown.setAttribute("required", "required");
            }
    
            // Add an event listener to the radio buttons
            var radioButtons = document.querySelectorAll("input[name='transaksi']");
            radioButtons.forEach(function(radioButton) {
                radioButton.addEventListener("change", function() {
                    if (radioButton.id === "sales") {
                        // If "sales" radio button is selected, make the select required
                        salesDropdown.setAttribute("required", "required");
                    } else {
                        // If any other radio button is selected, remove the required attribute
                        salesDropdown.removeAttribute("required");
                    }
                });
            });
        });
    </script>

	<script>
		function openEditModal(barangId) {
			// Fetch data for the selected barang_id using an AJAX request
			$.ajax({
				url: '<?= base_url('barangmasuk/get_data/') ?>' + barangId, // Replace with your actual URL
				type: 'GET',
				dataType: 'json',
				success: function(data) {
					// Populate the modal with the retrieved data
					// $('#barang_id').val(data.barang_id).trigger('change');
					$('#barang_nid').val(data[0].nama_barang);
					$('#barang_id').val(data[0].barang_id);
					$('#qty').val(data[0].qty);
					$('#harganet').val(data[0].harganet);
					$('#price').val(data[0].price);
					$('#harga_akhir').val(data[0].harga);
					$('#grade').val(data[0].grade);
					$('#kd_lokasi_akhir').val(data[0].kd_lokasi);

					// Show the modal
					$('#editModal').modal('show');
				},
				error: function() {
					alert('Error fetching data.'); // Handle error gracefully
				}
			});
		}

		$(document).ready(function() {
			$("#barang_id").change(function() {
				var selectedBarangId = $(this).val();
				// alert(selectedBarangId);
				if (selectedBarangId !== "") {
					$.ajax({
						type: "GET",
						url: "<?= base_url('penjualan/get_barang_info/'); ?>"+selectedBarangId,
						// data: {
						// 	barang_id: selectedBarangId
						// },
						dataType: "json",
						success: function(response) {
							// console.log(response);
							if (response) {
								$("#nm_barang").val(response.nama_barang);
								$("#stok").val(response.stok);
							}
						}
					});
				} else {
					$("#nm_barang").val("");
					$("#stok").val("");
				}
			});
		});

		$(document).ready(function() {
			// Event listener for the #price select element
			$("#harganet").on("input", function() {
				// Get the value from #harganet
				var harganet = parseFloat($(this).val());

				// Get the selected value from #price or set it to 0 if not selected
				var selectedPrice = parseFloat($("#price").val()) || 0;

				// Check if harganet is not empty and greater than 0
				if (!isNaN(harganet) && harganet > 0) {
					// Calculate the harga
					var harga = harganet - (harganet * (selectedPrice / 100));

					// Update the #harga_akhir input
					$("#harga_akhir").val(harga); // Round to 2 decimal places
				} else {
					alert("Harganet must be a valid number greater than 0.");

					// Set focus on #harganet
					$(this).focus();

					// Reset #harga_akhir
					$("#harga_akhir").val("");
				}
			});

			// Event listener for the #price select element
			$("#price").keyup(function() {
                // Rest of your code remains the same
                var selectedPrice = parseFloat($(this).val()) || 0;
                var harganet = parseFloat($("#harganet").val());
            
                if (!isNaN(harganet) && harganet > 0) {
                    var harga = harganet - (harganet * (selectedPrice / 100));
                    $("#harga_akhir").val(harga);
                } else {
                    alert("Harganet must be a valid number greater than 0.");
                    $("#harganet").focus();
                    $("#harga_akhir").val("");
                }
            });

// 			$("#price").change(function() {
// 				// Get the selected value from #price or set it to 0 if not selected
// 				var selectedPrice = parseFloat($(this).val()) || 0;
// 				// Get the value from #harganet
// 				var harganet = parseFloat($("#harganet").val());
// 				// Check if harganet is not empty and greater than 0
// 				if (!isNaN(harganet) && harganet > 0) {
// 					// Calculate the harga
// 					var harga = harganet - (harganet * (selectedPrice / 100));
// 					// Update the #harga_akhir input
// 					$("#harga_akhir").val(harga); // Round to 2 decimal places
// 				} else {
// 					alert("Harganet must be a valid number greater than 0.");
// 					// Set focus on #harganet
// 					$("#harganet").focus();
// 					// Reset #harga_akhir
// 					$("#harga_akhir").val("");
// 				}
// 			});

			function resetModalForm() {
				// Clear input values and remove validation classes
				$("#barang_id").val("").trigger("change"); // Trigger a change event for select2
				$("#qty").val("");
				$("#harga_akhir").val("");
				$("#price").val("");
				$("#harganet").val("");
			}

			// Event listener for modal close (dismiss)
			$('#editModal').on('hidden.bs.modal', function() {
				resetModalForm();
			});
		});
	</script>
	
	<script>
        $('#invoiceForm').submit(function(event) {
            event.preventDefault(); // Prevent the default form submission
            var inputValue = $('#invoiceInput').val();
            var url = '<?=base_url()?>penjualan/retur/' + inputValue;
            // alert(url);
            window.location.href = url;
        });
        

        $(document).ready(function() {
            $('#invoiceInput').select2({
                placeholder: "Pilih Invoice",
            });
        });
    </script>

	<script type="text/javascript">
		$(function() {
			$('.date').datepicker({
				uiLibrary: 'bootstrap4',
				format: 'yyyy-mm-dd'
			});

			$('.date1').datepicker({
				uiLibrary: 'bootstrap4',
				format: 'yyyy-mm-dd'
			});

			var start = moment().subtract(29, 'days');
			var end = moment();

			function cb(start, end) {
				// $('#tanggal').val(start.format('YYYY-MM-DD') + ' - ' + end.format('YYYY-MM-DD'));
				$('#tanggal').val(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
			}

			$('#tanggal').daterangepicker({
				startDate: start,
				endDate: end,
				ranges: {
					'Hari ini': [moment(), moment()],
					'Kemarin': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
					'7 hari terakhir': [moment().subtract(6, 'days'), moment()],
					'30 hari terakhir': [moment().subtract(29, 'days'), moment()],
					'Bulan ini': [moment().startOf('month'), moment().endOf('month')],
					'Bulan lalu': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
					'Tahun ini': [moment().startOf('year'), moment().endOf('year')],
					'Tahun lalu': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')]
				}
			}, cb);

			cb(start, end);
		});

		// date filter
		$(function() {
			$('#datefilter').daterangepicker({
				autoUpdateInput: false,
				locale: {
					cancelLabel: 'Clear'
				}
			});

			$('#datefilter').on('apply.daterangepicker', function(ev, picker) {
				$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
			});

			$('#datefilter').on('cancel.daterangepicker', function(ev, picker) {
				$(this).val('');
			});
		});

		$(document).ready(function() {
			var table = $('#dataTable').DataTable({
				buttons: ['copy', 'csv', 'print', 'excel', 'pdf'],
				dom: "<'row px-2 px-md-4 pt-2'<'col-md-3'l><'col-md-5 text-center'B><'col-md-4'f>>" +
					"<'row'<'col-md-12'tr>>" +
					"<'row px-2 px-md-4 py-3'<'col-md-5'i><'col-md-7'p>>",
				lengthMenu: [
					[5, 10, 25, 50, 100, -1],
					[5, 10, 25, 50, 100, "All"]
				],
				columnDefs: [{
					targets: -1,
					orderable: false,
					searchable: false
				}]
			});

			table.buttons().container().appendTo('#dataTable_wrapper .col-md-5:eq(0)');
		});

		$(document).ready(function() {
			var table = $('#dataTable1').DataTable({
				// buttons: ['copy', 'csv', 'print', 'excel', 'pdf'],
				dom: "<'row px-2 px-md-4 pt-2'<'col-md-3'l><'col-md-5 text-center'><'col-md-4'f>>" +
					"<'row'<'col-md-12'tr>>" +
					"<'row px-2 px-md-4 py-3'<'col-md-5'i><'col-md-7'p>>",
				lengthMenu: [
					[5, 10, 25, 50, 100, -1],
					[5, 10, 25, 50, 100, "All"]
				],
				columnDefs: [{
					targets: -1,
					orderable: false,
					searchable: false
				}]
			});

			table.buttons().container().appendTo('#dataTable_wrapper .col-md-5:eq(0)');
		});
	</script>

	<script>
		$(document).ready(function() {
			// show the alert
			setTimeout(function() {
				$(".alert").alert('close');
			}, 2000);
		});
	</script>
	<script>
		$(document).ready(function() {
			$(".select2").select2({
				placeholder: "Search...",
				width: "100%" // Adjust the width as needed
			});
		});

		$(document).ready(function() {
			$(document).ready(function() {
				// Initialize the Select2 plugin
				$("#voucher").select2();

				// Function to calculate the grand total
				function calculateGrandTotal() {
					var subtotal = parseInt($("#subtotal").val()) || 0;
					var nego = parseInt($("#nego").val()) || 0;
					var voucher = parseInt($("#voucher").val()) || 0;
					if (nego==0) {
						var grandtotal = subtotal - voucher;
					} else {
						var grandtotal = nego - voucher;
					}

					var grandtotalFormatted = grandtotal.toLocaleString('id-ID');
					$("#grandtotal").val(grandtotal);
					$("#tampilkan").html(grandtotalFormatted);
					$("#grandtotal_trans").val(grandtotal);
				}

				// Calculate the initial grand total when the page loads
				calculateGrandTotal();

				// Add an event listener to the "Reset" button
				$("#resetVoucher").on("click", function() {
					// Reset the select element to its default state (no selected option)
					$("#voucher").val(null).trigger('change.select2');
					$("#voucher_trans").val(0);
					// Recalculate the grand total
					calculateGrandTotal();
				});

				// Add an event listener to the "voucher" select element
				$("#voucher").on("change", function() {
					// Recalculate the grand total
					var selectedOptionText = $("#voucher option:selected").text();
					var kdVoucher = selectedOptionText.split(' | ')[0].trim();
					// $("#voucher_trans").val($(this).val());
					$("#voucher_trans").val(kdVoucher);
					calculateGrandTotal();
				});
				$("#nego").on("keyup", function() {
					// Recalculate the grand total
					var negoo = $(this).val();
					// $("#voucher_trans").val($(this).val());
					$("#nego_trans").val(negoo);
					calculateGrandTotal();
				});
				$("#payment").on("change", function() {
					$("#payment_trans").val($(this).val());
				});
				$("#sales_id").on("change", function() {
					$("#sales_id_trans").val($(this).val());
				});
				$("#cust_id").on("change", function() {
					$("#cust_id_trans").val($(this).val());
				});
				$("#cust_dp").on("keyup", function() {
					$("#cust_dp_trans").val($(this).val());
				});
			});
		});

		$(document).ready(function() {
			// Retrieve data from the first form and populate the second form
			$("#cust_id_trans").val($("#cust_id").val());
			$("#tanggal_trans").val($("#tanggal_").val());
			$("#user_id_trans").val();
			$("#subtotal_trans").val($("#subtotal").val());
			$("#voucher_trans").val(0);
		});
	</script>



	<script>
		// data detail
		let qty = $('#qty');
		let harga_d = $('#harga_d');
		let diskon = $('#diskon');
		let pajak_d = $('#pajak_d');
		let jumlah_d = $('#jumlah_d').val(0);

		$(document).on('keyup', '#qty', function() {
			let jml_d = parseInt(this.value);
			jumlah_d.val(jml_d);
		});

		$(document).on('keyup', '#harga_d', function() {
			let a = qty.val() * harga_d.val();
			let jml_d = parseInt(a);
			jumlah_d.val(jml_d);
		});

		$(document).on('keyup', '#diskon', function() {
			let a = qty.val() * harga_d.val();
			let b = a * this.value / 100;
			let jml_d = parseInt(a) - parseInt(b);
			jumlah_d.val(jml_d);
		});

		$(document).on('keyup', '#pajak_d', function() {
			let z = $("input[name='kategori']:checked").val();
			let a = qty.val() * harga_d.val();
			let b = a * diskon.val() / 100;
			let c = a - b;
			let d = c * this.value / 100;
			if (z == 'PT') {
				let jml_d = parseInt(c) + parseInt(d);
				jumlah_d.val(jml_d);
			} else {
				let jml_d = parseInt(c);
				jumlah_d.val(jml_d);
			}
		});

		$(document).ready(function() {
			$("input[type='radio']").click(function() {
				var rd = $("input[name='kategori']:checked").val();
				var nm = $('#nama');
				var al = $('#alamat');
				if (rd == 'PT') {
					nm.attr('placeholder', 'Nama PT ...');
					al.attr('placeholder', 'Alamat PT ...');
				} else {
					nm.attr('placeholder', 'Nama...');
					al.attr('placeholder', 'Alamat...');
				}
			});
		});

		$(document).on('click', '#add_d', function() {
			$('.bd-example-modal-lg').modal('show');
		});

		// data invoice top
		let subtotal = $('#subtotal');
		let pajak = $('#pajak');
		let total = $('#total');
		let pajak_inc = $('#pajak_inc');
		let jumlah_tagihan = $('#jumlah_tagihan').val(0);

		$(document).on('keyup', '#diskon_tambah', function() {
			let a = subtotal.val() * this.value / 100;
			let jml_d = parseInt(subtotal.val()) - parseInt(a);
			total.val(jml_d);
			jumlah_tagihan.val(jml_d);
		});

		$(document).on('keyup', '#pajak_inc', function() {
			let z = $("input[name='kategori']:checked").val();
			let a = ((100 / (100 + parseFloat(this.value))) * total.val()) * parseFloat(this.value) / 100;
			if (z == 'PT') {
				let jml_d = parseInt(total.val()) + a;
				jumlah_tagihan.val(jml_d.toFixed(2));
			} else {
				let jml_d = parseInt(total.val());
				jumlah_tagihan.val(jml_d);
			}
		});

		// data pelanggan
		let nama = $('#nama');
		let no_telp = $('#no_telp');
		let alamat = $('#alamat');
		let email = $('#emaill');
		let data = $('#data');

		$(document).on('keyup', '#nama', function() {
			let a = this.value;
			data.val(a + ":-:-:-");
		});

		$(document).on('keyup', '#no_telp', function() {
			let a = nama.val();
			let b = a + ":-:" + this.value + ":-";
			data.val(b);
		});

		$(document).on('keyup', '#alamat', function() {
			let a = nama.val();
			let b = no_telp.val();
			let c = a + ":" + this.value + ":" + b + ":-";
			data.val(c);
		});

		$(document).on('keyup', '#emaill', function() {
			let a = nama.val();
			let b = no_telp.val();
			let c = alamat.val();
			let d = a + ":" + c + ":" + b + ":" + this.value;
			data.val(d);
		});
	</script>

	<script type="text/javascript">
		let hal = '<?= $this->uri->segment(1); ?>';

		let satuan = $('#satuan');
		let stok = $('#stok');
		let total1 = $('#total_stok');
		let hargam = $('#harga_masuk');
		let ukuran = $('#ukuran');
		let jumlah = hal == 'barangmasuk' ? $('#jumlah_masuk') : $('#jumlah_keluar');

		// $(document).on('change', '#barang_id', function() {
		// 	let url = '<?= base_url('barang/getstok/'); ?>' + this.value;
		// 	$.getJSON(url, function(data) {
		// 		satuan.html(data.nama_satuan);
		// 		stok.val(data.stok);
		// 		total1.val(data.stok);
		// 		jumlah.focus();
		// 	});
		// });

		// $(document).on('keyup', '#jumlah_masuk', function() {
		//     let totalStok = parseInt(stok.val()) + parseInt(this.value);
		//     total.val(Number(totalStok));
		// });

		$(document).on('keyup', '#jumlah_keluar', function() {
			let totalStok = parseInt(stok.val()) - parseInt(this.value);
			total1.val(Number(totalStok));
		});

		$(document).on('keyup', '#jumlah_kardus', function() {
			let totalStok = parseInt(stok.val()) - parseInt(this.value);
			total1.val(Number(totalStok));
		});

		$(document).on('keyup', '#qty_pcs', function() {
			let totalStok = parseInt(stok.val()) - parseInt(this.value);
			total1.val(Number(totalStok));
		});

		// ukuran key up
		$(document).on('keyup', '#panjang', function() {
			let br = $("#berat").val();
			let lb = $("#lebar").val();
			if (br == '' && lb == '') {
				ukuran.val(this.value + ':0:0');
			} else {
				ukuran.val(this.value + ':' + lb + ':' + br);
			}
		});
		$(document).on('keyup', '#lebar', function() {
			let pj = $("#panjang").val();
			let br = $("#berat").val();
			if (br == '' && pj == '') {
				ukuran.val(this.value + ':0:0');
			} else if (br == '' && pj > 0) {
				ukuran.val(pj + ':' + this.value + ':0');
			} else {
				ukuran.val(pj + ':' + this.value + ':' + br);
			}
		});
		$(document).on('keyup', '#berat', function() {
			let pj = $("#panjang").val();
			let lb = $("#lebar").val();
			ukuran.val(pj + ':' + lb + ':' + this.value);
		});

		$(document).on('change', '#satuan_m', function() {
			// let jmlm = $('#qty_pcs').val();
			// let qtym = $('#jumlah_masuk');
			// if (this.value==3 || this.value==3) {
			//     let totalStok = parseInt(stok.val()) + parseInt(jmlm);
			//     total.val(totalStok + ' Pcs');
			//     qtym.val(parseInt(jmlm));
			// } else if (this.value==1 || this.value==1) {
			//     let totalStok = parseInt(stok.val()) + parseInt(jmlm*1000/10);
			//     total.val(totalStok + ' Pcs');
			//     qtym.val(parseInt(jmlm*1000/10));
			// } else {
			//     let totalStok = parseInt(stok.val()) + parseInt(jmlm/10);
			//     total.val(totalStok + ' Pcs');
			//     qtym.val(parseInt(jmlm/10));
			// }
			// hargam.focus();
			$("#panjang").focus();
		});
	</script>

	<?php if ($this->uri->segment(1) == 'dashboard') : ?>
		<!-- Chart -->
		<script src="<?= base_url(); ?>assets/vendor/chart.js/Chart.min.js"></script>
		
		<script type="text/javascript">
		    console.log(<?=$transformed_data?>);
			// Set new default font family and font color to mimic Bootstrap's default styling
			Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
			Chart.defaults.global.defaultFontColor = '#858796';

			function number_format(number, decimals, dec_point, thousands_sep) {
				// *     example: number_format(1234.56, 2, ',', ' ');
				// *     return: '1 234,56'
				number = (number + '').replace(',', '').replace(' ', '');
				var n = !isFinite(+number) ? 0 : +number,
					prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
					sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
					dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
					s = '',
					toFixedFix = function(n, prec) {
						var k = Math.pow(10, prec);
						return '' + Math.round(n * k) / k;
					};
				// Fix for IE parseFloat(0.55).toFixed(0) = 0;
				s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
				if (s[0].length > 3) {
					s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
				}
				if ((s[1] || '').length < prec) {
					s[1] = s[1] || '';
					s[1] += new Array(prec - s[1].length + 1).join('0');
				}
				return s.join(dec);
			}

			// Area Chart Example
			var ctx = document.getElementById("myAreaChart");
			var myLineChart = new Chart(ctx, {
				type: 'line',
				data: {
					labels: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"],
					datasets: [{
							label: "Total Barang Masuk",
							lineTension: 0.3,
							backgroundColor: "rgba(78, 115, 223, 0.05)",
							borderColor: "rgba(78, 115, 223, 1)",
							pointRadius: 3,
							pointBackgroundColor: "rgba(78, 115, 223, 1)",
							pointBorderColor: "rgba(78, 115, 223, 1)",
							pointHoverRadius: 3,
							pointHoverBackgroundColor: "#5a5c69",
							pointHoverBorderColor: "#5a5c69",
							pointHitRadius: 10,
							pointBorderWidth: 2,
							data: <?= json_encode($cbm); ?>,
						},
						{
							label: "Total Barang Keluar",
							lineTension: 0.3,
							backgroundColor: "rgba(231, 74, 59, 0.05)",
							borderColor: "#e74a3b",
							pointRadius: 3,
							pointBackgroundColor: "#e74a3b",
							pointBorderColor: "#e74a3b",
							pointHoverRadius: 3,
							pointHoverBackgroundColor: "#5a5c69",
							pointHoverBorderColor: "#5a5c69",
							pointHitRadius: 10,
							pointBorderWidth: 2,
							data: <?= json_encode($cbk); ?>,
						}
					],
				},
				options: {
					maintainAspectRatio: false,
					layout: {
						padding: 5
					},
					scales: {
						xAxes: [{
							time: {
								unit: 'date'
							},
							gridLines: {
								display: false,
								drawBorder: false
							},
							ticks: {
								maxTicksLimit: 7
							}
						}],
						yAxes: [{
							ticks: {
								maxTicksLimit: 5,
								padding: 10,
								// Include a dollar sign in the ticks
								callback: function(value, index, values) {
									return number_format(value);
								}
							},
							gridLines: {
								color: "rgb(234, 236, 244)",
								zeroLineColor: "rgb(234, 236, 244)",
								drawBorder: false,
								borderDash: [2],
								zeroLineBorderDash: [2]
							}
						}],
					},
					legend: {
						display: false
					},
					tooltips: {
						backgroundColor: "rgb(255,255,255)",
						bodyFontColor: "#858796",
						titleMarginBottom: 10,
						titleFontColor: '#6e707e',
						titleFontSize: 14,
						borderColor: '#dddfeb',
						borderWidth: 1,
						xPadding: 15,
						yPadding: 15,
						displayColors: false,
						intersect: false,
						mode: 'index',
						caretPadding: 10,
						callbacks: {
							label: function(tooltipItem, chart) {
								var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
								return datasetLabel + ': ' + number_format(tooltipItem.yLabel);
							}
						}
					}
				}
			});

			// Pie Chart Example
			var ctx = document.getElementById("myPieChart");
			var myPieChart = new Chart(ctx, {
				type: 'doughnut',
				data: {
					labels: ["Barang Masuk", "Barang Keluar"],
					datasets: [{
						data: [<?= $barang_masuk; ?>, <?= $barang_keluar; ?>],
						backgroundColor: ['#4e73df', '#e74a3b'],
						hoverBackgroundColor: ['#5a5c69', '#5a5c69'],
						hoverBorderColor: "rgba(234, 236, 244, 1)",
					}],
				},
				options: {
					maintainAspectRatio: false,
					tooltips: {
						backgroundColor: "rgb(255,255,255)",
						bodyFontColor: "#858796",
						borderColor: '#dddfeb',
						borderWidth: 1,
						xPadding: 15,
						yPadding: 15,
						displayColors: false,
						caretPadding: 10,
					},
					legend: {
						display: false
					},
					cutoutPercentage: 80,
				},
			});
		</script>
	<?php endif; ?>
</body>

</html>
