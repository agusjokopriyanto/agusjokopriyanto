<?= $this->session->flashdata('pesan'); ?>
<div class="row">
    <div class="col-xl-3 col-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Nama Customer</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$datacs[0]['nama_cust']?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-tag fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Grand Total Pembelian</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. <?=number_format($datacs[0]['grandtotal'],0,',','.')?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-wallet fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Customer DP</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. <?=number_format($datacs[0]['cust_dp'],0,',','.')?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-money-bill fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Hutang</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><span id="hutang">0</span></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-wallet fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
			    
<div class="card shadow-sm border-bottom-primary">
	<div class="card-header bg-white py-3">
		<div class="row">
			<div class="col">
				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
					Cicilan Customer
				</h4>
			</div>
			<div class="col-auto">
			<?=form_open('penjualan/cicilan', 'class="form-inline"',[]); ?>
              <div class="form-group mx-sm-3 mb-2">
                <input type="hidden" name="aksi" value="tambah">
                <input type="hidden" name="nota_cs" value="<?=$datacs[0]['no_notap']?>">  
                <input type="hidden" name="cs_id" value="<?=$datacs[0]['cust_id']?>">  
                <input type="number" class="form-control" name="cicilan" placeholder="0" required>
              </div>
              <button type="submit" class="btn btn-primary mb-2">Tambah Cicilan</button>
            <?=form_close()?>
			</div>
			<div class="col-auto">
				<!--<a href="<?= base_url('penjualan/cicil') ?>" class="btn btn-sm btn-primary btn-icon-split">-->
				<!--	<span class="icon">-->
				<!--		<i class="fa fa-plus"></i>-->
				<!--	</span>-->
				<!--	<span class="text">-->
				<!--		Tambah Cicilan-->
				<!--	</span>-->
				<!--</a>-->
			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
			<thead>
				<tr>
					<th>No. </th>
					<th>Tanggal</th>
					<th>Nominal Cicilan</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				$grandtotal = $datacs[0]['grandtotal'];
				$dp = $datacs[0]['cust_dp'];
				$sumCicil = 0;
                $hutang = 0;
                
				if ($cicilan) :
					foreach ($cicilan as $bm) :
					    $sumCicil += $bm['cicilan'];
				?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= date("Y-m-d", strtotime($bm['create_at'])); ?></td>
							<td><?= number_format($bm['cicilan'],0,',','.'); ?></td>
							<td>
							    <?=form_open('penjualan/cicilan', 'class="form-inline"',[]); ?>
                                  <div class="form-group mx-sm-3 mb-2">
                                    <input type="hidden" name="aksi" value="hapus">
                                    <input type="hidden" name="nota_cs" value="<?=$datacs[0]['no_notap']?>"> 
                                    <input type="hidden" name="id_" value="<?=$bm['id_']?>">
                                  </div>
                                  <button type="submit" class="btn btn-danger mb-2 btn-sm"><i class="fa fa-trash"></i></button>
                                <?=form_close()?>
								<!--<a href="<?= base_url('penjualan/del_dcs/') . $bm['id_'] ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>-->
							</td>
						</tr>
					<?php endforeach; $result = ($grandtotal - $dp) - $sumCicil;?>
				<?php else : ?>
					<tr>
						<td colspan="4" class="text-center">
							Data Kosong
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
		<?php
		    echo '<script>';
            echo 'var result = ' . $result . ';'; // Set the JavaScript variable 'result'
            echo 'var formattedResult = new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(result);';
            echo 'document.getElementById("hutang").textContent = formattedResult;';
            echo '</script>';
        ?>
	</div>
</div>
