<div class="row justify">
	<div class="col-md-8">
		<div class="card shadow-sm border-bottom-primary">
			<div class="card-body">
				<?= form_open('penjualan/proses_d2', [], ['d_pj' => $no_notap]); ?>
				<div class="row form-group">
					<label class="col-md-3 text-md-right" for="barang_id">SKU</label>
					<div class="col-md-8">
						<select name="barang_id" id="barang_id" class="select2">
							<option value="" selected disabled>Pilih SKU</option>
							<?php foreach ($barang as $b) : ?>
								<option value="<?= $b['id_barang'] ?>"><?= $b['id_barang'] ?></option>
							<?php endforeach; ?>
						</select>
						<?= form_error('barang_id', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-3 text-md-right" for="barang_id">Produk</label>
					<div class="col-md-8">
						<input type="text" id="nm_barang" class="form-control" readonly placeholder="Nama Barang">
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-3 text-md-right" for="">Qty</label>
					<div class="col-md-3">
						<input type="number" name="qty" id="qty" class="form-control">
						<?= form_error('qty', '<small class="text-danger">', '</small>'); ?>
					</div>
					<label class="col-md-2 text-md-right" for="">Stok</label>
					<div class="col-md-3">
						<input type="number" id="stok" class="form-control" readonly>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-3 text-md-right" for="">Harga</label>
					<div class="col-md-5">
						<input type="number" name="harga" id="harga" class="form-control">
						<?= form_error('harga', '<small class="text-danger">', '</small>'); ?>
					</div>
					<div class="col-md-4">
						<button type="submit" class="btn btn-primary"><i class="fas fa-cart-plus"></i> Add</button>
						<button type="reset" class="btn btn-secondary">Reset</button>
					</div>
				</div>
				<?= form_close(); ?>
			</div>
		</div>
	</div>

	<div class="col-md-4">
		<div class="card shadow-sm border-bottom-primary">
			<div class="card-body">
				<div class="row form-group">
					<label class="col-md-3 text-md-right" for="">Date</label>
					<div class="col-md-9">
						<input value="<?= set_value('tanggal_', $data_header[0]['tanggal_']); ?>" name="tanggal_" id="tanggal_" type="text" class="form-control date" >
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-3 text-md-right" for="">Kasir</label>
					<div class="col-md-9">
						<input type="text" value="<?= $data_header[0]['nama']; ?>" name="kasir" id="kasir" class="form-control" readonly>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<br>

<div class="row justify">
	<div class="col-md-12">
		<div class="card shadow-sm border-bottom-primary">
			<div class="card-body">
				<div class="row form-group">
					<div class="col-md-1">
					</div>
					<div class="col-md-12">
						<div class="">
							<table class="table table-striped table-responsive-lg">
								<thead>
									<tr>
										<th>No. </th>
										<th>Nama Barang</th>
										<th>Harga</th>
										<th>Qty</th>
										<th>Total</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$no = 1;
									$subtotal = 0;
									if ($data_detail) :
										foreach ($data_detail as $bm) :
											$total = $bm['harga'] * $bm['qty'];
									?>
											<tr>
												<td><?= $no++; ?></td>
												<td><?= $bm['nama_barang'] ?></td>
												<td style="text-align:right;"><?= number_format($bm['harga'],0,',','.'); ?></td>
												<td><?= $bm['qty']; ?></td>
												<td style="text-align:right"><?= number_format($total, 0, ',', '.'); ?></td>
												<td>
												    <?= form_open('penjualan/retur_d', [], ['d_pj' => $no_notap, 'barang_id' => $bm['barang_id'],'qty' => $bm['qty'], 'status' => 'RETUR']); ?>
												    <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-undo"></i> Retur</button>
													<?= form_close(); ?>
												</td>
											</tr>
										<?php $subtotal += $total;
										endforeach; ?>
									<?php else : ?>
										<tr>
											<td colspan="7" class="text-center">
												Data Kosong
											</td>
										</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<br>

<div class="row justify">
	<div class="col-md-7">
		<div class="card shadow-sm border-bottom-primary">
			<div class="card-body">
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="">Sub Total</label>
					<div class="col-md-6">
						<input type="number" value="<?= $subtotal ?>" name="subtotal" id="subtotal" class="form-control" readonly>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="">Harga Nego</label>
					<div class="col-md-6">
						<input type="number" name="nego" id="nego" class="form-control" value="<?=$data_header[0]['nego']?>">
						<?= form_error('nego', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="">Voucher</label>
					<div class="col-md-7">
						<div class="input-group">
							<select name="voucher" id="voucher" class="select2 custom-select">
								<option value="" selected disabled>Pilih Voucher</option>
								<?php foreach ($voucher as $b) : ?>
									<option value="<?= $b['nominal'] ?>" <?= ($data_header[0]['voucher'] === $b['kd_voucher']) ? 'selected' : ''; ?>><?= $b['kd_voucher'] . ' | Rp.' . number_format($b['nominal']) ?></option>
								<?php endforeach; ?>
							</select>
							<div class="input-group-append">
								<button id="resetVoucher" class="btn btn-danger btn-sm" type="button"><i class="fas fa-times"></i></button>
							</div>
						</div>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="">Grand Total</label>
					<div class="col-md-6">
						<input type="number" value="0" name="grandtotal" id="grandtotal" class="form-control" readonly>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="">Payment Via</label>
					<div class="col-md-7">
						<div class="input-group">
						    <?php $selectedPayment = $data_header[0]['payment'];?>
						    <select name="payment" id="payment" class="select2 custom-select">
                                <option value="" disabled>Pilih Payment</option>
                                <option value="DANA" <?= ($selectedPayment === "DANA") ? 'selected' : ''; ?>>DANA</option>
                                <option value="OVO" <?= ($selectedPayment === "OVO") ? 'selected' : ''; ?>>OVO</option>
                                <option value="CASH" <?= ($selectedPayment === "CASH") ? 'selected' : ''; ?>>CASH</option>
                                <option value="TRANSFER" <?= ($selectedPayment === "TRANSFER") ? 'selected' : ''; ?>>TRANSFER</option>
                                <option value="EDC" <?= ($selectedPayment === "EDC") ? 'selected' : ''; ?>>EDC</option>
                                <option value="AKULAKU" <?= ($selectedPayment === "AKULAKU") ? 'selected' : ''; ?>>AKULAKU</option>
                            </select>
							<?= form_error('payment', '<small class="text-danger">', '</small>'); ?>
						</div>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="">Sales</label>
					<div class="col-md-6">
						<select name="sales_id" id="sales_id" class="select2">
							<option value="" selected disabled>Pilih Sales</option>
							<?php foreach ($sales as $b) : ?>
								<option value="<?= $b['id_sales'] ?>" <?= ($data_header[0]['sales_id'] === $b['id_sales']) ? 'selected' : ''; ?>><?= $b['nama_sales'] ?></option>
							<?php endforeach; ?>
						</select>
						<?= form_error('sales_id', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for=""></label>
					<div class="col-md-6">
						<?= form_open('penjualan/proses_t2', [], ['no_notap' => $no_notap]); ?>
						<div style="display: none;">
							<input type="text" name="tanggal_" id="tanggal_trans">
							<?= form_error('tanggal_', '<small class="text-danger">', '</small>'); ?>
							<input type="text" name="user_id" id="user_id_trans" value="<?= userdata('id_user'); ?>">
							<?= form_error('user_id', '<small class="text-danger">', '</small>'); ?>
							<input type="text" name="subtotal" id="subtotal_trans">
							<?= form_error('subtotal', '<small class="text-danger">', '</small>'); ?>
							<input type="text" name="nego" id="nego_trans" value="0">
							<?= form_error('nego', '<small class="text-danger">', '</small>'); ?>
							<input type="text" name="voucher" id="voucher_trans">
							<?= form_error('voucher', '<small class="text-danger">', '</small>'); ?>
							<input type="text" name="grandtotal" id="grandtotal_trans">
							<?= form_error('grandtotal', '<small class="text-danger">', '</small>'); ?>
							<input type="text" name="payment" id="payment_trans" value="<?=$data_header[0]['payment']?>">
							<?= form_error('payment', '<small class="text-danger">', '</small>'); ?>
							<input type="text" name="sales_id" id="sales_id_trans" value="<?=$data_header[0]['sales_id']?>">
							<?= form_error('sales_id', '<small class="text-danger">', '</small>'); ?>
							<input type="text" name="status" value="Not Approve">
							<input type="text" name="selesai" value="0">
						</div>
						<button type="text" class="btn btn-success"> <i class="fas fa-paper-plane"></i> Proses Approval</button>
						<?= form_close(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="col-md-5">
		<div class="card shadow-sm border-bottom-primary">
			<div class="card-body">
				<div class="row form-group">
					<div class="col-md-12">
						<p id="" class="text-right">
						    Invoice <b><?= $no_notap; ?></b>
						    <br>
						    <span>Harga Awal : <?= number_format($subtotal, 0, ',','.') ?></span>
						</p>
						<p id="" class="text-right" style="font-size: 32pt;">
							Rp. <span id="tampilkan">0</span>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
