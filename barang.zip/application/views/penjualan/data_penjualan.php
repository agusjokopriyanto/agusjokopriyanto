<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
	<div class="card-header bg-white py-3">
		<div class="row">
			<div class="col">
				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
					Riwayat Data Penjualan
				</h4>
			</div>
			<div class="col-auto">
			    <form action="" id="invoiceForm" class="form-inline">
                  <div class="form-group mx-sm-3 mb-2">
                     <select id="invoiceInput" class="select2 form-control" required>
                        <option value="">Pilih No Invoice</option>
                        <?php foreach ($pnotap as $record): ?>
                            <option value="<?=$record['no_notap']; ?>"><?=$record['no_notap']; ?></option>
                        <?php endforeach; ?>
                    </select>
                  </div>
                    <button class="btn btn-warning btn-icon-split mb-2" type="submit" id="button-addon1">
                        <span class="icon">
                            <i class="fa fa-undo"></i>
                        </span>
                        <span class="text">
                            Retur Barang
                        </span>
                    </button>
                </form>
				<!--<div class="btn-group">-->
				<!--	<a href="<?= base_url('penjualan/retur') ?>" class="btn btn-sm btn-warning btn-icon-split">-->
				<!--		<span class="icon">-->
				<!--			<i class="fa fa-undo"></i>-->
				<!--		</span>-->
				<!--		<span class="text">-->
				<!--			Retur Barang-->
				<!--		</span>-->
				<!--	</a> &nbsp;-->
				<!--	<a href="<?= base_url('penjualan/cancel') ?>" class="btn btn-sm btn-danger btn-icon-split">-->
				<!--		<span class="icon">-->
				<!--			<i class="fa fa-window-close"></i>-->
				<!--		</span>-->
				<!--		<span class="text">-->
				<!--			Cancel Barang-->
				<!--		</span>-->
				<!--	</a>-->
				<!--</div>-->
			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
			<thead>
				<tr>
					<th>No. </th>
					<th>Invoice</th>
					<th>Tanggal Transaksi</th>
					<th>Kasir</th>
					<th>Sales</th>
					<th>Grand Total</th>
					<th>Status</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				if ($datapo) :
					foreach ($datapo as $bm) :
				?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= $bm['no_notap']; ?></td>
							<td><?= $bm['tanggal_']; ?></td>
							<td><?= $bm['nama']; ?></td>
							<td><?= $bm['nama_sales']; ?></td>
							<td><?= number_format($bm['grandtotal'], 0, ',', '.'); ?></td>
							<td><?= $bm['status']; ?></td>
							<td>
								<?php if ($bm['status'] !== 'Not Approve') : ?>
									<a href="<?= base_url('penjualan/cetak_/') . $bm['no_notap'] ?>" target="_blank" class="btn btn-sm btn-info"><i class="fa fa-print"></i> Print</a>
								<?php else : ?>
									<button class="btn btn-sm btn-info" disabled><i class="fa fa-print"></i> Print</button>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="8" class="text-center">
							Data Kosong
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
