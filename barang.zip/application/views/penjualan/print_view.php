<!DOCTYPE html>
<html>

<head>
	<title><?= $title; ?></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			background-color: grey;
		}

		.container {
			/*height: 297mm;*/
			max-height: 297mm;
			max-width: 210mm;
			margin: 0 auto;
			padding: 0 20px;
			background-color: white;
		}

		.footer {
			text-align: right;
			margin-top: 20px;
			font-size: 14px;
		}

		td {
			padding: 5px;
		}

		th {
			padding: 5px;
		}
	</style>
</head>

<body>
	<div class="container">
		<table border="0" style="width: 100%">
			<thead>
				<tr>
					<th style="text-align: left; width:150px">No Invoice</th>
					<td>: <?= $invoice ?></td>
					<th style="text-align: left;">Kasir</th>
					<td>: <?= $data_header[0]['nama'] ?></td>
				</tr>
				<tr>
					<th style="text-align: left;">Tanggal Invoice</th>
					<td>: <?= $data_header[0]['tanggal_'] ?></td>
					<th style="text-align: left;">Sales</th>
					<td>: <?= $data_header[0]['nama_sales'] ?></td>
				</tr>
				<!--<tr>-->
				<!--	<th style="text-align: left;">Kasir</th>-->
				<!--	<td>: <?= $data_header[0]['nama'] ?></td>-->
				<!--</tr>-->
				<!--<tr>-->
				<!--	<th style="text-align: left;">Sales</th>-->
				<!--	<td>: <?= $data_header[0]['nama_sales'] ?></td>-->
				<!--</tr>-->
			</thead>
		</table>
		<hr>
		<table class="isi" style="border-collapse: collapse; width: 100%;">
			<thead>
				<tr>
					<th style="text-align: left;">Nama Barang</th>
					<th>Harga</th>
					<th>Qty</th>
					<th colspan="2">Total</th>
				</tr>
			</thead>
			<tbody style="border-bottom: 1px solid grey;">
				<?php
				$no=1;
				$subtotal = 0;
				foreach ($data_detail as $bm) :
					$total = $bm['harga'] * $bm['qty'];
				?>
					<tr>
						<td><?= $no++ . '. '.$bm['nama_barang'] ?></td>
						<td style="text-align: right;"><?= formatCurrency($bm['harga']); ?></td>
						<td style="text-align: center;"><?= $bm['qty']; ?></td>
						<td colspan="2" style="text-align: right;"><?= formatCurrency($total); ?></td>
					</tr>
				<?php $subtotal += $total;
				endforeach; ?>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="1" style="text-align: right;"></th>
					<th colspan="3" style="text-align: left;">Sub Total</th>
					<th style="text-align: right;"><?= formatCurrency($data_header[0]['subtotal']) ?></th>
				</tr>
				<tr>
					<th colspan="1" style="text-align: right;"></th>
					<th colspan="3" style="text-align: left;">Harga Nego</th>
					<th style="text-align: right;"><?= formatCurrency($data_header[0]['nego']) ?></th>
				</tr>
				<tr>
					<th colspan="1" style="text-align: right;"></th>
					<th colspan="3" style="text-align: left;">Voucher</th>
					<th style="text-align: right;">
						<?php
						// Assuming you're using CodeIgniter's Active Record
						$query = $this->db->get_where('voucher', ['kd_voucher' => $data_header[0]['voucher']]);

						if ($query->num_rows() > 0) {
							$voucherData = $query->row_array(); // Get the voucher data as an associative array
							echo $nominal = formatCurrency($voucherData['nominal']); // Retrieve the 'nominal' column value
						} else {
							// Handle the case where no voucher with the specified kd_voucher is found
							echo $nominal = 0; // You can set a default value or handle it as needed
						}
						?>
					</th>
				</tr>
				<tr>
					<th colspan="1" style="text-align: right;"></th>
					<th colspan="3" style="text-align: left;">Grand Total</th>
					<th style="text-align: right;"><?= formatCurrency($data_header[0]['grandtotal']) ?></th>
				</tr>
			</tfoot>
		</table>
	</div>

	<script>
		window.onload = function() {
			// This function will be called when the page has fully loaded
			window.print(); // Trigger the print dialog
		};
	</script>
</body>

</html>
<?php
function formatCurrency($number)
{
	$fmt = new NumberFormatter('id-ID', NumberFormatter::DECIMAL);
	return $fmt->format($number);
}
?>
