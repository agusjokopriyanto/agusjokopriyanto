<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
	<div class="card-header bg-white py-3">
		<div class="row">
			<div class="col">
				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
					Riwayat Data Penjualan CS
				</h4>
			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
			<thead>
				<tr>
					<th>No. </th>
					<th>Invoice</th>
					<th>Tanggal Transaksi</th>
					<th>Nama Customer</th>
					<th>DP Customer</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				if ($datapo) :
					foreach ($datapo as $bm) :
				?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= $bm['no_notap']; ?></td>
							<td><?= $bm['tanggal_']; ?></td>
							<td><?= $bm['nama_cust']; ?></td>
							<td><?= number_format($bm['cust_dp'],0,',','.'); ?></td>
							<td>
								<a href="<?= base_url('penjualan/detailcs/') . $bm['no_notap'] ?>" class="btn btn-sm btn-info"><i class="fa fa-eye"></i> Detail</a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="8" class="text-center">
							Data Kosong
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
