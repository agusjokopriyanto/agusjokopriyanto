<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
	<div class="card-header bg-white py-3">
		<div class="row">
			<div class="col">
				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
					Data Approval
				</h4>
			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
			<thead>
				<tr>
					<th>No. </th>
					<th>Invoice</th>
					<th>Tanggal Transaksi</th>
					<th>Kasir</th>
					<th>Sales</th>
					<th>Grand Total</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				if ($datapo) :
					foreach ($datapo as $bm) :
				?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= $bm['no_notap']; ?></td>
							<td><?= $bm['tanggal_']; ?></td>
							<td><?= $bm['nama']; ?></td>
							<td><?= $bm['nama_sales']; ?></td>
							<td><?= number_format($bm['grandtotal'], 0, ',', '.'); ?></td>
							<td>
								<a href="#" class="btn btn-sm btn-info" data-toggle="modal" data-target="#myModal<?= $bm['no_notap']; ?>"><i class="fa fa-eye"></i> Check</a>
								<div class="modal fade" id="myModal<?= $bm['no_notap']; ?>">
									<div class="modal-dialog modal-lg">
										<div class="modal-content">
											<div class="modal-header">
												<h4 class="modal-title">Check Details</h4>
												<button type="button" class="close" data-dismiss="modal">&times;</button>
											</div>
											<div class="modal-body">
												<table style="width:100%" class="table-responsive">
													<tr>
														<th>No Invoice</th>
														<td>: <?= $bm['no_notap'] ?></td>
														<th>Tanggal Inv</th>
														<td>: <?= $bm['tanggal_'] ?></td>
														<th>Kasir</th>
														<td>: <?= $bm['nama'] ?></td>
														<th>Sales</th>
														<td>: <?= $bm['nama_sales'] ?></td>
													</tr>
												</table>
												<br>
												<table style="width: 100%;">
													<thead>
														<tr>
															<th>Nama Barang</th>
															<th>Harga</th>
															<th>Qty</th>
															<th colspan="2">Total</th>
														</tr>
													</thead>
													<tbody>
														<?php
														$subtotal = 0;
														$this->db->join('barang b', 'pd.barang_id = b.id_barang');
														$this->db->where('d_pj', $bm['no_notap']);
														$this->db->order_by('d_pj', 'DESC');
														$data_detail = $this->db->get('penjualan_d pd')->result_array();
														foreach ($data_detail as $dd) :
															$total = $dd['harga'] * $dd['qty'];
														?>
															<tr>
																<td><?= $dd['nama_barang'] ?></td>
																<td><?= number_format($dd['harga']); ?></td>
																<td><?= $dd['qty']; ?></td>
																<td colspan="2"><?= number_format($total); ?></td>
															</tr>
														<?php $subtotal += $total;
														endforeach; ?>
													</tbody>
													<tfoot>
														<tr>
															<th colspan="2"></th>
															<th colspan="2">Sub Total</th>
															<th><?= number_format($bm['subtotal']) ?></th>
														</tr>
														<tr>
															<th colspan="2"></th>
															<th colspan="2">Harga Nego</th>
															<th><?= number_format($bm['nego']) ?></th>
														</tr>
														<tr>
															<th colspan="2"></th>
															<th colspan="2">Voucher</th>
															<th>
																<?php
																// Assuming you're using CodeIgniter's Active Record
																$query = $this->db->get_where('voucher', ['kd_voucher' => $bm['voucher']]);

																if ($query->num_rows() > 0) {
																	$voucherData = $query->row_array(); // Get the voucher data as an associative array
																	echo $nominal = number_format($voucherData['nominal']); // Retrieve the 'nominal' column value
																} else {
																	// Handle the case where no voucher with the specified kd_voucher is found
																	echo $nominal = 0; // You can set a default value or handle it as needed
																}
																?>
															</th>
														</tr>
														<tr>
															<th colspan="2"></th>
															<th colspan="2">Grand Total</th>
															<th><?= number_format($bm['grandtotal']) ?></th>
														</tr>
													</tfoot>
												</table>
											</div>
											<div class="modal-footer">
												<?= form_open('approval/app', [], ['no_notap' => $bm['no_notap']]); ?>
												<input type="hidden" name="status" value="Approve">
												<button type="submit" class="btn btn-success"><i class="fas fa-check"></i> Approve</button>
												<?= form_close(); ?>
												<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

							</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="8" class="text-center">
							Data Kosong
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>