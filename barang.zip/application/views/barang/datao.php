<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
	<div class="card-header bg-white py-3">
		<div class="row">
			<div class="col">
				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
					Data Barang
				</h4>
			</div>
			<div class="col-auto">
				<span class="text-danger">*</span><span><b>Note :</b> Stok <= 5 , block baris dalam tabel berwarna hitam!!</span>
			</div>
			
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
			<thead>
				<tr>
					<th>No. </th>
					<th>SKU</th>
					<th>Nama Barang</th>
					<th>Kategori</th>
					<th>Stok</th>
					<th>Satuan</th>
					<th>Lokasi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				if ($barang) :
					foreach ($barang as $b) :
				?>
						<tr style="<?= $b['stok'] <= 5 ? 'background-color: grey; color: white;' : '' ?>">
							<td><?= $no++; ?></td>
							<td><?= $b['barang_id']; ?></td>
							<td><?= $b['nama_barang']; ?></td>
							<td><?= $b['nama_kategori']; ?></td>
							<td><?= $b['stok']; ?></td>
							<td><?= $b['nama_satuan']; ?></td>
							<td><?= $b['kd_lokasi']; ?></td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="7" class="text-center">
							Data Kosong
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
