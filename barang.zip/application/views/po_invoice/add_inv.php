<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Input Invoice
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('invoice') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Kembali
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <!-- isi dari top invoice -->
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open('invoice/proses_t', []); ?>
                <div class="row form-group">
                    <label class="col-md-2 text-md-right" for="no_po_inv">No Invoice</label>
                    <div class="col-md-4">
                        <input readonly value="<?= set_value('no_po_inv', $no_po_inv); ?>" name="no_po_inv" id="no_po_inv" type="text" class="form-control" placeholder="No Invoice">
                        <?= form_error('no_po_inv', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-2 text-md-right" for="tanggal_">Tanggal</label>
                    <div class="col-md-4">
                        <input value="<?= set_value('tanggal_', date('Y-m-d')); ?>" name="tanggal_" id="tanggal_" type="text" class="form-control date" placeholder="Tanggal Masuk...">
                        <?= form_error('tanggal_', '<small class="text-danger">', '</small>'); ?>
                    </div>
                    <label class="col-md-2 text-md-right" for="tanggal_tempo">Tanggal Tempo</label>
                    <div class="col-md-3">
                        <input value="<?= set_value('tanggal_tempo', date('Y-m-d')); ?>" name="tanggal_tempo" id="tanggal_tempo" type="text" class="form-control date1" placeholder="Tanggal Tempo...">
                        <?= form_error('tanggal_tempo', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-2 text-md-right" for="kategori">Pilih Data</label>
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="radio">
                                <label>
                                    <input type="radio" name="kategori" id="kategori" value="P" required>
                                    Perorangan &nbsp;
                                </label>
                                <label>
                                    <input type="radio" name="kategori" id="kategori" value="PT" required>
                                    Khusus PT
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-2 text-md-right" for="nama">Nama</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            <input id="nama" type="text" class="form-control" placeholder="Nama ..." required="required">
                        </div>
                    </div>
                    <label class="col-md-2 text-md-right" for="no_telp">Nomor Telepon</label>
                    <div class="col-md-3">
                        <div class="input-group">
                            <input id="no_telp" type="text" class="form-control" placeholder="Nomor Telepon..." required="required">
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-2 text-md-right" for="alamat">Alamat</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            <textarea id="alamat" class="form-control" rows="2" placeholder="Alamat..." required="required"><?= set_value('alamat'); ?></textarea>
                        </div>
                    </div>
                    <label class="col-md-2 text-md-right" for="emaill">Email</label>
                    <div class="col-md-3">
                        <div class="input-group">
                            <input id="emaill" type="email" class="form-control" placeholder="Email">
                        </div>
                    </div>
                    <input type="hidden" name="data" id="data" class="form-control">
                </div>
                <div class="row form-group">
                    <div class="col-md-1">                        
                    </div>
                    <div class="col-md-10">
                        <!-- <button id="add_d" class="btn btn-primary btn-icon-split" data-toggle="modal" data-target=".bd-example-modal-lg"> -->
                        <button id="add_d" class="btn btn-primary btn-icon-split" type="button">
                            <span class="icon">
                                <i class="fa fa-plus"></i>
                            </span>
                            <span class="text">
                                Add Detail
                            </span>
                        </button>
                        <div class="">
                            <table class="table table-striped table-responsive-lg">
                                <thead>
                                    <tr>
                                        <th>No. </th>
                                        <th>Nama Barang</th>
                                        <!-- <th>Deskripsi</th> -->
                                        <th>Qty</th>
                                        <th>Harga</th>
                                        <th>Diskon</th>
                                        <th>Pajak</th>
                                        <th>Jumlah</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    if ($data_detail) :
                                        foreach ($data_detail as $bm) :
                                            ?>
                                            <tr>
                                                <td><?= $no++; ?></td>
                                                <td><?= $bm['nama_barang'] ?></td>
                                                <!-- <td><?= $bm['deskripsi']; ?></td> -->
                                                <td><?= $bm['qty']; ?></td>
                                                <td><?= "Rp " . number_format($bm['harga_d'],0,',','.') ?></td>
                                                <td><?= $bm['diskon'].' %'; ?></td>
                                                <td><?= $bm['pajak_d'].' %'; ?></td>
                                                <td><?= number_format($bm['jumlah_d'],0,',','.'); ?></td>
                                                <td>
                                                    <a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('invoice/del_d/').$no_po_inv ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else : ?>
                                        <tr>
                                            <td colspan="8" class="text-center">
                                                Data Kosong
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
                <div class="row form-group">
                    <label class="col-md-2 text-md-right" for="subtotal">Subtotal</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            <input value="<?=$subttl?>" name="subtotal" id="subtotal" type="text" class="form-control" placeholder="Subtotal ..." readonly="readonly">
                        </div>
                        <!-- <?= form_error('subtotal', '<small class="text-danger">', '</small>'); ?> -->
                    </div>
                    <label class="col-md-2 text-md-right" for="pajak">Pajak</label>
                    <div class="col-md-3">
                        <div class="input-group">
                            <input value="<?=$sumpajak?>" name="pajak" id="pajak" type="text" class="form-control" placeholder="Pajak" readonly="readonly">
                            <!-- <div class="input-group-append">
                                <span class="input-group-text">%</span>
                            </div> -->
                        </div>
                        <?= form_error('pajak', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-2 text-md-right" for="total">Total</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            <input value="<?=$subttl?>" name="total" id="total" type="text" class="form-control" placeholder="Total ..." readonly="readonly">
                        </div>
                        <!-- <?= form_error('total', '<small class="text-danger">', '</small>'); ?> -->
                    </div>
                    <label class="col-md-2 text-md-right" for="pajak_inc">Pajak Inclusive</label>
                    <div class="col-md-3">
                        <div class="input-group">
                            <input name="pajak_inc" id="pajak_inc" type="number" step="0.01" class="form-control" placeholder="Pajak Inclusive">
                            <div class="input-group-append">
                                <span class="input-group-text">%</span>
                            </div>
                        </div>
                        <?= form_error('pajak_inc', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-2 text-md-right" for="jumlah_tagihan">Jumlah Tagihan</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            <input value="<?=$subttl?>" name="jumlah_tagihan" id="jumlah_tagihan" type="number" step="0.01" class="form-control" placeholder="Jumlah Tagihan" readonly="readonly">
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col offset-md-2">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Detail Invoice</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
  </div>
  <div class="modal-body">
    <!-- form detail invoice -->
    <?= form_open('invoice/proses_d', []); ?>
    <div class="row form-group">
        <label class="col-md-2 text-md-right" for="barang_id">Produk</label>
        <div class="col-md-4">
            <input readonly value="<?= set_value('d_po_inv', $no_po_inv); ?>" name="d_po_inv" id="d_po_inv" type="hidden" class="form-control" placeholder="No Invoice">
            <select name="namabarang" id="namabarang" class="custom-select">
                <option value="" selected disabled>Pilih Barang</option>
                <?php foreach ($barang as $b) : ?>
                    <option <?= $this->uri->segment(3) == $b['id_barang'] ? 'selected' : '';  ?> <?= set_select('barang_id', $b['id_barang']) ?> value="<?= $b['id_barang'] ?>"><?= $b['id_barang'] . ' | ' . $b['nama_barang'] ?></option>
                <?php endforeach; ?>
            </select>
            <!-- <div class="input-group">
                <input name="namabarang" id="namabarang" type="text" class="form-control" placeholder="Nama Barang">
                <?= form_error('namabarang', '<small class="text-danger">', '</small>'); ?>
            </div> -->
            <?= form_error('idbarang', '<small class="text-danger">', '</small>'); ?>
        </div>
        <label class="col-md-2 text-md-right" for="deskripsi">Deskripsi</label>
        <div class="col-md-4">
            <div class="input-group">
                <textarea name="deskripsi" id="deskripsi" class="form-control" rows="2" placeholder="Deskripsi..."><?= set_value('deskripsi'); ?></textarea>
            </div>
            <?= form_error('deskripsi', '<small class="text-danger">', '</small>'); ?>
        </div>
    </div>
    <div class="row form-group">
        <label class="col-md-2 text-md-right" for="qty">Quantity</label>
        <div class="col-md-4">
            <input name="qty" id="qty" type="number" class="form-control" placeholder="Quantity...">
            <?= form_error('qty', '<small class="text-danger">', '</small>'); ?>
        </div>
        <label class="col-md-2 text-md-right" for="harga_d">Harga</label>
        <div class="col-md-4">
            <input name="harga_d" id="harga_d" type="number" class="form-control" placeholder="Harga...">
            <?= form_error('harga_d', '<small class="text-danger">', '</small>'); ?>
        </div>
    </div>
    <div class="row form-group">
        <label class="col-md-2 text-md-right" for="diskon">Diskon</label>
        <div class="col-md-4">
            <div class="input-group">
                <input name="diskon" id="diskon" type="number" step="0.01" class="form-control" placeholder="Diskon">
                <div class="input-group-append">
                    <span class="input-group-text">%</span>
                </div>
            </div>
            <?= form_error('diskon', '<small class="text-danger">', '</small>'); ?>
        </div>
        <label class="col-md-2 text-md-right" for="pajak_d">Pajak</label>
        <div class="col-md-4">
            <div class="input-group">
                <input name="pajak_d" id="pajak_d" type="number" step="0.01" class="form-control" placeholder="Pajak ...">
                <div class="input-group-append">
                    <span class="input-group-text">%</span>
                </div>
            </div>
            <?= form_error('pajak_d', '<small class="text-danger">', '</small>'); ?>
        </div>
    </div>
    <div class="row form-group">
        <label class="col-md-2 text-md-right" for="jumlah_d">Jumlah</label>
        <div class="col-md-4">
            <div class="input-group">
                <input readonly="readonly" name="jumlah_d" id="jumlah_d" type="text" class="form-control" placeholder="jumlah">
            </div>
        </div>
    </div>
    <div class="row form-group">
        <div class="col offset-md-2">
            <button type="submit" class="btn btn-primary">Add</button>
            <button type="reset" class="btn btn-secondary">Reset</button>
        </div>
    </div>
    <?= form_close(); ?>
</div>
</div>
</div>
</div>