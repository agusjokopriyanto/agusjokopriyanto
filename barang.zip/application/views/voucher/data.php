<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
	<div class="card-header bg-white py-3">
		<div class="row">
			<div class="col">
				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
					Data Voucher
				</h4>
			</div>
			<div class="col-auto">
				<form action="<?= site_url('voucher/import_excel') ?>" method="post" enctype="multipart/form-data">
				<input type="hidden" value="voucher" name="tabel">
				<input name="uploadFile" type="file" accept=".xls,.xlsx,.csv" required>
				<input type="submit" name="import" value="Import Excel" class="btn btn-success btn-sm">
				</form>
			</div>
			<div class="col-auto">
				<div class="btn-group">
					<a href="<?= base_url('assets/format/formatvoucher.xls') ?>" class="btn btn-sm btn-warning btn-icon-split">
						<span class="icon">
							<i class="fa fa-file-download"></i>
						</span>
						<span class="text">
							Format
						</span>
					</a> &nbsp;
					<a href="<?= base_url('voucher/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
						<span class="icon">
							<i class="fa fa-plus"></i>
						</span>
						<span class="text">
							Tambah Voucher
						</span>
					</a>
				</div>

			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-striped" id="dataTable">
			<thead>
				<tr>
					<th>No. </th>
					<th>Kode Voucher</th>
					<th>Nominal</th>
					<th>Tanggal Kadaluarsa</th>
					<th>Status</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				if ($voucher) :
					foreach ($voucher as $j) :
				?>
						<tr style="<?= $j['tgl_expired'] < date('Y-m-d') ? 'background-color: grey; color:white;' : ''; ?>">
							<td><?= $no++; ?></td>
							<td><?= $j['kd_voucher']; ?></td>
							<td>Rp. <?= number_format($j['nominal'],0,',','.'); ?></td>
							<td><?= $j['tgl_expired']; ?></td>
							<td><?= $j['status'] == 0 ? 'Belum Digunakan' : 'Sudah Digunakan'; ?></td>
							<td>
								<a href="<?= base_url('voucher/edit/') . $j['id_voucher'] ?>" class="btn btn-warning btn-circle btn-sm"><i class="fa fa-edit"></i></a>
								<a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('voucher/delete/') . $j['id_voucher'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="6" class="text-center">
							Data Kosong
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
