<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
	<div class="card-header bg-white py-3">
		<div class="row">
			<div class="col">
				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
					Data Kategori
				</h4>
			</div>
			<div class="col-auto">
				<form action="<?= site_url('kategori/import_excel') ?>" method="post" enctype="multipart/form-data">
				<input type="hidden" value="kategori" name="tabel">
				<input name="uploadFile" type="file" accept=".xls,.xlsx,.csv" required>
				<input type="submit" name="import" value="Import Excel" class="btn btn-success btn-sm">
				</form>
			</div>
			<div class="col-auto">
				<div class="btn-group">
					<a href="<?= base_url('assets/format/formatkategori.xls') ?>" class="btn btn-sm btn-warning btn-icon-split">
						<span class="icon">
							<i class="fa fa-file-download"></i>
						</span>
						<span class="text">
							Format
						</span>
					</a> &nbsp;
					<a href="<?= base_url('kategori/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
						<span class="icon">
							<i class="fa fa-plus"></i>
						</span>
						<span class="text">
							Tambah Kategori
						</span>
					</a>
				</div>

			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-striped" id="dataTable">
			<thead>
				<tr>
					<th>No. </th>
					<th>Kode Kategori</th>
					<th>Nama Kategori</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				if ($kategori) :
					foreach ($kategori as $j) :
				?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= $j['kd_kategori']; ?></td>
							<td><?= $j['nama_kategori']; ?></td>
							<td>
								<a href="<?= base_url('kategori/edit/') . $j['id_kategori'] ?>" class="btn btn-warning btn-circle btn-sm"><i class="fa fa-edit"></i></a>
								<a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('kategori/delete/') . $j['id_kategori'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="4" class="text-center">
							Data Kosong
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
