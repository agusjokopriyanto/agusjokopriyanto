<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
	<div class="card-header bg-white py-3">
		<div class="row">
			<div class="col">
				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
					Riwayat Data Barang Broken
				</h4>
			</div>
			<div class="col-auto">
				<a href="<?= base_url('barangbroken/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
					<span class="icon">
						<i class="fa fa-plus"></i>
					</span>
					<span class="text">
						Input Data
					</span>
				</a>
			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
			<thead>
				<tr>
					<th>No. </th>
					<th>#</th>
					<th>No Inv</th>
					<th>Tanggal</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				if ($datapo) :
					foreach ($datapo as $bm) :
						$noinv = explode('-', $bm['no_po']);
				?>
						<tr>
							<td><?= $no++; ?></td>
							<th><a href="<?= base_url('barangbroken/lihat/') . $bm['no_po'] ?>" class="btn btn-sm btn-info btn-circle"><i class="fa fa-plus"></i></a></th>
							<td><?= $noinv[0] . '/' . $noinv[1] ?></td>
							<td><?= $bm['tanggal_']; ?></td>
							<td>
								<!-- <a href="<?= base_url('barangbroken/print_/') . $bm['no_po'] ?>" target="_blank" class="btn btn-sm btn-info btn-circle"><i class="fa fa-file-pdf"></i></a> -->
								<a onclick="return confirm('Yakin ingin menghapus data?')" href="<?= base_url('barangbroken/delete/') . $bm['no_po'] ?>" class="btn btn-circle btn-sm btn-danger"><i class="fa fa-fw fa-trash"></i></a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="8" class="text-center">
							Data Kosong
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
