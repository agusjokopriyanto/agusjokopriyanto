<div class="row justify-content-center">
	<div class="col-md-12">
		<div class="card shadow-sm border-bottom-primary">
			<div class="card-header bg-white py-3">
				<div class="row">
					<div class="col-auto">
						<a href="<?= base_url('barangbroken') ?>" class="btn btn-sm btn-secondary btn-icon-split">
							<span class="icon">
								<i class="fa fa-arrow-left"></i>
							</span>
							<span class="text">
								Kembali
							</span>
						</a>
					</div>
				</div>
			</div>
			<div class="card-body">
				<div class="row form-group">
					<div class="col-md-1">
					</div>
					<div class="col-md-12">
						<div class="table-responsive">
							<table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
								<thead>
									<tr>
										<th>No. </th>
										<th>SKU</th>
										<th>Nama Barang</th>
										<th>Qty</th>
										<th>Harga</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$no = 1;
									if ($data_detail) :
										foreach ($data_detail as $bm) :
									?>
											<tr>
												<td><?= $no++; ?></td>
												<td><?= $bm['id_barang'] ?></td>
												<td><?= $bm['nama_barang'] ?></td>
												<td><?= $bm['qty_bkn']; ?></td>
												<td><?= number_format($bm['harga_j'],0,',','.'); ?></td>
											</tr>
										<?php endforeach; ?>
									<?php else : ?>
										<tr>
											<td colspan="5" class="text-center">
												Data Kosong
											</td>
										</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
