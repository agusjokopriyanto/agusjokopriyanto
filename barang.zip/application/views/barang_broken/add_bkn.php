<div class="row justify-content-center">
	<div class="col-md-10">
		<div class="card shadow-sm border-bottom-primary">
			<div class="card-header bg-white py-3">
			    <div class="row">
        			<div class="col">
        				<h4 class="h5 align-middle m-0 font-weight-bold text-primary">
        					Form Input Data Barang Broken
        				</h4>
        			</div>
        			<div class="col-auto">
        				<form action="<?= site_url('barangbroken/import_excel') ?>" method="post" enctype="multipart/form-data">
        				<input type="hidden" value="barang_broken_d" name="tabel">
        				<input name="uploadFile" type="file" accept=".xls,.xlsx,.csv" required>
        				<input type="submit" name="import" value="Import Excel" class="btn btn-success btn-sm">
        				</form>
        			</div>
        			<div class="col-auto">
        				<div class="btn-group">
        					<a href="<?= base_url('assets/format/formatbkn.xls') ?>" class="btn btn-sm btn-warning btn-icon-split">
        						<span class="icon">
        							<i class="fa fa-file-download"></i>
        						</span>
        						<span class="text">
        							Format
        						</span>
        					</a> &nbsp;
        					<a href="<?= base_url('barangbroken') ?>" class="btn btn-sm btn-secondary btn-icon-split">
    							<span class="icon">
    								<i class="fa fa-arrow-left"></i>
    							</span>
    							<span class="text">
    								Kembali
    							</span>
    						</a>
        				</div>
        			</div>
        		</div>
				
			</div>
			<div class="card-body">
				<!-- isi dari top barangbroken -->
				<?= $this->session->flashdata('pesan'); ?>
				<?= form_open('barangbroken/proses_t', []); ?>
				<div class="row form-group">
					<label class="col-md-2 text-md-right" for="no_po">No Inv</label>
					<div class="col-md-4">
						<input readonly value="<?= set_value('no_po', $no_po); ?>" name="no_po" id="no_po" type="text" class="form-control" placeholder="No barangbroken">
						<?= form_error('no_po', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-2 text-md-right" for="tanggal_">Tanggal</label>
					<div class="col-md-4">
						<input value="<?= set_value('tanggal_', date('Y-m-d')); ?>" name="tanggal_" id="tanggal_" type="text" class="form-control date" placeholder="Tanggal Masuk...">
						<?= form_error('tanggal_', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-md-1">
					</div>
					<div class="col-md-10">
						<!-- <button id="add_d" class="btn btn-primary btn-icon-split" data-toggle="modal" data-target=".bd-example-modal-lg"> -->
						<button id="add_d" class="btn btn-primary btn-icon-split" type="button">
							<span class="icon">
								<i class="fa fa-plus"></i>
							</span>
							<span class="text">
								Add Detail
							</span>
						</button>
						<div class="">
						    <br>
							<table class="table table-striped table-responsive-lg">
								<thead>
									<tr>
										<th>No. </th>
										<th>Nama Barang</th>
										<th>Qty</th>
										<th>Harga</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$no = 1;
									if ($data_detail) :
										foreach ($data_detail as $bm) :
									?>
											<tr>
												<td><?= $no++; ?></td>
												<td><?= $bm['nama_barang'] ?></td>
												<td><?= $bm['qty_bkn']; ?></td>
												<td><?= number_format($bm['harga_j'],0,',','.'); ?></td>
												<td>
													<a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('barangbroken/del_d/') . $no_po ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
												</td>
											</tr>
										<?php endforeach; ?>
									<?php else : ?>
										<tr>
											<td colspan="5" class="text-center">
												Data Kosong
											</td>
										</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="row form-group">
					<div class="col offset-md-2">
						<button type="submit" class="btn btn-primary">Simpan</button>
						<button type="reset" class="btn btn-secondary">Reset</button>
					</div>
				</div>
				<?= form_close(); ?>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Add Detail Barang Broken</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<!-- form detail barangbroken -->
				<?= form_open('barangbroken/proses_d', []); ?>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="barang_id">Produk</label>
					<div class="col-md-6">
						<input readonly value="<?= set_value('d_po', $no_po); ?>" name="d_po" id="d_po" type="hidden" class="form-control" placeholder="No barangbroken">
						<select name="barang_id" id="barang_id" class="select2">
							<option value="" selected disabled>Pilih Barang</option>
							<?php foreach ($barang as $b) : ?>
								<option value="<?= $b['id_barang'] ?>"><?= $b['id_barang'] . ' | ' . $b['nama_barang'] ?></option>
							<?php endforeach; ?>
						</select>

						<?= form_error('barang_id', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="qty_bkn">Quantity</label>
					<div class="col-md-6">
						<input name="qty_bkn" id="qty_bkn" type="number" class="form-control" placeholder="Quantity...">
						<?= form_error('qty_bkn', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<label class="col-md-4 text-md-right" for="harga_j">Harga Jual</label>
					<div class="col-md-6">
						<input name="harga_j" id="harga_j" type="number" class="form-control" placeholder="Harga jual...">
						<?= form_error('harga_j', '<small class="text-danger">', '</small>'); ?>
					</div>
				</div>
				<div class="row form-group">
					<div class="col offset-md-4">
						<button type="submit" class="btn btn-primary">Add</button>
						<button type="reset" class="btn btn-secondary">Reset</button>
					</div>
				</div>
				<?= form_close(); ?>
			</div>
		</div>
	</div>
</div>
